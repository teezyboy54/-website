<?php 
session_start();
error_reporting(0);
include('includes/config.php');

// code for insert product in order table


if(isset($_SESSION['remove'])){
header("Refresh:0");}
$_SESSION['remove'] =null;
?>

<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php'); ?>


<body>
<!-- HEADER -->
<!-- HEADER -->
<header>
<!-- top Header -->
<?php  include('includes/top-header.php'); ?>
<!-- /top Header -->

<!-- header -->
<?php  include('includes/main-header.php'); ?>

<!-- container -->




</header>
<!-- /HEADER -->



<!-- NAVIGATION -->
<?php include 'includes/main-nav.php'; ?>
<!-- /NAVIGATION -->

<!-- BREADCRUMB -->
<div id="breadcrumb">
<div class="container">
<ul class="breadcrumb">
<li><a href="index.php">Home</a></li>
<li class="active">My Cart</li>
</ul>
</div>
</div>
<!-- /BREADCRUMB -->

<!-- section -->
<div class="section">
<!-- container -->
<div class="container">
<!-- row -->
<div class="row">	

<?php
if(!empty($_SESSION['cart'])){
?>
<div class="col-md-12">
<div class="order-summary clearfix">
<div class="section-title">
	<?php 
	if(isset($_SESSION['edit']))
	{
		echo "<center><span style='color: green;'>".  $_SESSION['edit']."</span></center>";
	}
	$_SESSION['edit'] =null;
	 ?>
	 
<br>	 
<h3 class="title">Order Review</h3>
</div>
<table class="shopping-cart-table table">
<thead>
<tr>
<th class="text-center">Remove</th>
<th class="text-center">Image</th>
<th class="text-center">Product Name</th>
<th class="text-center">Quantity</th>
<!--<th class="text-center">Price Per unit</th>
<th class="text-center">Delivery Charge</th>-->
<th clas="text-center">Grandtotal</th>

</tr>
</thead>
<tbody>
<?php
$pdtid=array();
$sql = "SELECT * FROM products WHERE id IN(";
foreach($_SESSION['cart'] as $id => $value){
$sql .=$id. ",";
}
$sql=substr($sql,0,-1) . ") ORDER BY id ASC";
$query = mysqli_query($con,$sql);
$totalprice=0;
$totalqunty=0;
$subtotaL=0;
$shippingCharge=0;
if(!empty($query)){
while($row = mysqli_fetch_array($query)){
$quantity=$_SESSION['cart'][$row['id']]['quantity'];

$subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productPrice'];
$subtota= $_SESSION['cart'][$row['id']]['quantity']*$row['productPrice'];
//$shippingChargeL= $row['shippingCharge'];

$subtotaL += $subtota;
//$shippingCharge +=$shippingChargeL;
$_SESSION['qnty']=$totalqunty+=$quantity;

array_push($pdtid,$row['id']);
//print_r($_SESSION['pid'])=$pdtid;exit;
?>
<tr>

<td class="romove-item"><form name="cart" method="post"  action="includes/deletecart.php">
								<!--<a href="product-page.php?page=product&action=add&id=<?php echo $row['id'];?>" >-->
									<input type="hidden" name="remove_code[]" value="<?php echo htmlentities($row['id']);?>" />
								<a onclick="return confirm('Do Want To Remove From Cart');" clss="label label-danger"><button class="primary-btn add-to-cart" name="delete"><i class="fa fa-remove"></i> <!--Remove--></button></a>
								</form></td>
<td class="thumb"><img src="admin/productimages/<?php echo $row['id'];?>/<?php echo $row['productImage1'];?>" alt="" width="114" height="98"></td>
<td class="details">
<h4 class='details'><a href="product-page.php?pid=<?php echo htmlentities($pd=$row['id']);?>" ><?php echo $row['productName'];

$_SESSION['sid']=$pd;
?></a></h4>


</td>

<td class="qty text-center">






<!--<form name="cart" method="post" name="myform" action="includes/increment.php">-->
<div class="form-group">
        <div class="input-group" style="width: 112px;">
            <div class="input-group-btn">
                <button id="down" class="btn btn-default" onclick=" down('0')"><span class="glyphicon glyphicon-minus" ></span></button>
            </div>
            <input type="text" id="myNumber"  class="form-control input-number" value="<?php echo $_SESSION['cart'][$row['id']]['quantity']; ?>" name="quantity[<?php echo $row['id']; ?>]" />
            <div class="input-group-btn">
                <button id="up" class="btn btn-default" onclick="up('100')"><span class="glyphicon glyphicon-plus"  ></span></button>
            </div>
        </div>
    </div>



<script type="text/javascript">
			
			function up(max) {
	    document.getElementById("myNumber").value = parseInt(document.getElementById("myNumber").value) + 1;
	    if (document.getElementById("myNumber").value >= parseInt(max)) {
	        document.getElementById("myNumber").value = max;
	    }

	}
	
	function down(min) {
	    document.getElementById("myNumber").value = parseInt(document.getElementById("myNumber").value) - 1;
	    if (document.getElementById("myNumber").value <= parseInt(min)) {
	        document.getElementById("myNumber").value = min;
	    }
	}
	function Charge(val){
		var textbox= document.getElementById('myNumber');
		var textboxname =textbox.name;
		location.href='includes/increment.php?inc='+textboxname;
	}
//location.href='includes/increment.php';
		</script>


	
<!--</div>-->
</td>
<!--<td class="cart-product-sub-total"><span class="cart-sub-total-price"><?php echo "GH₵ "." ".$row['productPrice']. ".00"; ?></span></td>
<td class="cart-product-sub-total"><span class="cart-sub-total-price"><?php echo "GH₵ "." ".$row['shippingCharge']; ?>.00</span></td>-->

<td class="cart-product-grand-total" style="color: #e80505;"><span class="cart-grand-total-price"><?php echo "GH₵ ". ($_SESSION['cart'][$row['id']]['quantity']*$row['productPrice']).".00"; ?></span>
</tr>
<?php } }
$_SESSION['pid']=$pdtid;
?>
</tbody>
<tfoot>
<tr>
<td colspan="7">
<div class="shopping-cart-btn">
<span class="">
<a href="index.php" class="primary-btn btn-primary outer-left-xs">Continue Shopping</a>
<!--<input type="submit" name="submit" value="Update shopping cart" class="primary-btn btn-primary pull-right outer-right-xs">-->
</span>
</div><!-- /.shopping-cart-btn -->
</td>
</tr>
<tr>
<th class="empty" colspan="3"></th>
<th>SUBTOTAL</th>
<th colspan="2" class="sub-total"><?php echo "GH₵ ". $_SESSION['sub']="$subtotaL";
if($subtotaL >=1000 ){
$shippingCharge=$subtotaL*0.01;
}
else if($subtotaL >=681){
$shippingCharge=$subtotaL*0.010;
}
else if($subtotaL >=631){
$shippingCharge=$subtotaL*0.0102;
}
else if($subtotaL >=501  ){
$shippingCharge=$subtotaL*0.011;
}
else if($subtotaL >=400 ){
$shippingCharge=$subtotaL*0.013;
}
else if($subtotaL >=231 ){
$shippingCharge=$subtotaL*0.02;
}
else if($subtotaL >=171 ){
$shippingCharge=$subtotaL*0.03;
}
else if($subtotaL >=140  ){
$shippingCharge=$subtotaL*0.04;
}
else if($subtotaL >=101 ){
$shippingCharge=$subtotaL*0.05;
}
else if($subtotaL >=100  ){
$shippingCharge=$subtotaL*0.06;
}
else if($subtotaL >=81){
$shippingCharge=$subtotaL*0.07;
}
else if($subtotaL >=61){
$shippingCharge=$subtotaL*0.08;
}
else if($subtotaL >=42){
$shippingCharge=$subtotaL*0.1;
}
else if($subtotaL >=41 ){
$shippingCharge=$subtotaL*0.13;
}

else if($subtotaL >=31){
$shippingCharge=$subtotaL*0.15;
}
else if($subtotaL >=10){
$shippingCharge=$subtotaL*0.2;
}
else if($subtotaL >=1){
$shippingCharge=$subtotaL*0.7;
}
?></th>
</tr>
<tr>
<th class="empty" colspan="3"></th>
<th>DELIVERY</th>
<td colspan="2"><span style="color: white;">.......</span><?php echo "GH₵ ". $_SESSION['Delivery']="$shippingCharge"; ?></td>
</tr>

<tr>
<th class="empty" colspan="3"></th>
<th>TOTAL</th>
<th colspan="2" class="total"><?php
$totalprice = $subtotaL+$shippingCharge;
 echo "GH₵ ". $_SESSION['totalprice']="$totalprice"; ?></th>
</tr>
</tfoot>
</table>
<div class="pull-right">
<button class="primary-btn" name="ordersubmit">PROCCED</button>
</div>
</div>

</div>





<br>
</div>
<?php } else {

	if(isset($_SESSION['remove']))
	{
		echo "<center><span style='color: red;'>".  $_SESSION['edit']."</span></center>";
	}
	$_SESSION['remove'] =null;
	 
echo "Your shopping Cart is empty";
}?>
</div>

<!-- /row -->
</div>
<!-- /container -->

<!-- /section -->

<!-- FOOTER -->
<?php include('includes/footer.php'); ?>
<!-- /FOOTER -->

<!-- jQuery Plugins -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/nouislider.min.js"></script>
<script src="js/jquery.zoom.min.js"></script>
<script src="js/main.js"></script>

</body>

</html>
