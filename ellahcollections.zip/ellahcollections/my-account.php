
<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
    {   
header('location:login.php');
}
else{
	if(isset($_POST['update']))
	{
		$name=$_POST['name'];
		$contactno=$_POST['contactno'];
		$contactno1=$_POST['contactno1'];
		$address=$_POST['address'];
		$city=$_POST['city'];
		//$contactno=$_POST['contactno'];
		$query=mysqli_query($con,"update users set name='$name',contactno='$contactno',contactno1='$contactno1',shippingAddress='$address',shippingCity='$city' where id='".$_SESSION['id']."'");
		if($query)
		{
			header('location: Confirm.php');
//echo "<script>alert('Your Information Has Been updated');</script>";
  $_SESSION['edit'] ="Your Information Has Been updated";
		}
	}


date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );


if(isset($_POST['submit']))
{
$sql=mysqli_query($con,"SELECT password FROM  users where password='".md5($_POST['cpass'])."' && id='".$_SESSION['id']."'");
$num=mysqli_fetch_array($sql);
if($num>0)
{
 $con=mysqli_query($con,"update students set password='".md5($_POST['newpass'])."', updationDate='$currentTime' where id='".$_SESSION['id']."'");
echo "<script>alert('Password Changed Successfully !!');</script>";
}
else
{
	echo "<script>alert('Current Password not match !!');</script>";
}
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>E-SHOP HTML Template</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css" />
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

		<script type="text/javascript">
function valid()
{
 if(document.register.password.value!= document.register.confirmpassword.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.register.confirmpassword.focus();
return false;
}
return true;
}
</script>
    	<script>
function userAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'email='+$("#email").val(),
type: "POST",
success:function(data){
$("#user-availability-status1").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>

</head>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<?php  include('includes/top-header.php'); ?>
		<!-- /top Header -->

		<!-- header -->
		<?php  include('includes/main-header.php'); ?>
		
		<!-- container -->
	</header>
	<!-- /HEADER -->

	

	<!-- NAVIGATION -->
	<?php include 'includes/main-nav.php'; ?>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="#">Home</a></li>
				<li class="active">My Account</li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
			<form id="checkout-form" class="clearfix" method="post">
					<div class="col-md-6">
						<?php
$query=mysqli_query($con,"select * from users where id='".$_SESSION['id']."'");
while($row=mysqli_fetch_array($query))
{
?>

						<div class="billing-details">
							<!--<p>Already a customer ? <a href="#">Login</a></p>-->
							<div class="section-title">
								<h3 class="title">Shipping Details</h3>
							</div>
							<div class="form-group">
							<label class="info-title" for="exampleInputEmail1">Full Name <span style="color: red;">*</span></label>

								<input class="input" type="text"  value="<?php echo $row['name'];?>" id="name" name="name" required="required">
							</div>
							<label class="info-title" for="exampleInputEmail1">Email Address <span style="color: red;">*</span></label>
							<div class="form-group">
								<input class="input" type="text" id="exampleInputEmail1" value="<?php echo $row['email'];?>" readonly>
							</div>
							<div class="form-group">
								<label class="info-title" for="Contact No.">Contact No 1. <span style="color: red;">*</span></label>
								<input class="input" type="text" id="contactno" name="contactno" required="required" value="<?php echo $row['contactno'];?>"  maxlength="10">
							</div>
							<div class="form-group">
								<label class="info-title" for="Contact No.">Contact No 2. <span style="color: red;">*</span></label>
								<input class="input" type="text" id="contactno" name="contactno1" required="required" value="<?php echo $row['contactno1'];?>"  maxlength="10">
							</div>
							<div class="form-group">
								<label class="info-title" for="Contact No.">Address <span style="color: red;">*</span></label>
								<input class="input" type="text" name="address" required="required" value="<?php echo $row['shippingAddress'];?>">
							</div>
							<div class="form-group">
								<label class="info-title" for="Contact No.">Town <span style="color: red;">*</span></label>
								<input class="input" type="text"   name="city" required="required" value="<?php echo $row['shippingCity'];?>">
							</div>
							<input class="primary-btn" name="update" type="submit" value="Save">
							<?php } ?>
							<!--<div class="form-group">
								<div class="input-checkbox">
									<input type="checkbox" id="register">
									<label class="font-weak" for="register">Create Account?</label>
									<div class="caption">
										<label class="font-weak" for="register">Create Account?</label>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
											<p>
											<div class="form-group">
												<input class="input" type="text" name="zip-code" placeholder="ZIP Code">
											</div>
											<div class="form-group">
												<input class="input" type="tel" name="tel" placeholder="Telephone">
											</div>


									</div>
								</div>
							</div>-->
						</div>
					</div>

					<div class="col-md-6">
						<div class="shiping-methods">
							

										<?php include('includes/myaccount-sidebar.php');?><p>
								
							
							
							
						</div>

						<!--<div class="payments-methods">
							<div class="section-title">
								<h4 class="title">Payments Methods</h4>
							</div>
							<div class="input-checkbox">
								<input type="radio" name="payments" id="payments-1" checked>
								<label for="payments-1">Direct Bank Transfer</label>
								<div class="caption">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
										<p>
								</div>
							</div>
							<div class="input-checkbox">
								<input type="radio" name="payments" id="payments-2">
								<label for="payments-2">Cheque Payment</label>
								<div class="caption">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
										<p>
								</div>
							</div>
							<div class="input-checkbox">
								<input type="radio" name="payments" id="payments-3">
								<label for="payments-3">Paypal System</label>
								<div class="caption">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
										<p>
								</div>
							</div>
						</div>-->
					</div>


			</div>

			<!-- /row -->
		</div>
		<!-- /container -->

	<!-- /section -->
	
<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>
<!-- /FOOTER -->

<script>
		$(document).ready(function(){ 
			$(".changecolor").switchstylesheet( { seperator:"color"} );
			$('.show-theme-options').click(function(){
				$(this).parent().toggleClass('open');
				return false;
			});
		});

		$(window).bind("load", function() {
		   $('.show-theme-options').delay(2000).trigger('click');
		});
	</script>
	<!-- For demo purposes – can be removed on production : End -->

	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
