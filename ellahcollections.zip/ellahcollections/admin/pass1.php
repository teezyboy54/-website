<?php 

echo md5('aa');

 ?>