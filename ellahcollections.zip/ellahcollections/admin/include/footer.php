	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; 2023 Ellah Collections </b> All rights reserved.
		</div>
	</div>