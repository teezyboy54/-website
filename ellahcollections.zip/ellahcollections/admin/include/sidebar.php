<div class="span3">
					<div class="sidebar">

						<ul class="widget widget-menu unstyled">
                                <li><a href="todays-orders.php"><i class="menu-icon icon-tasks"></i> Daily Order </a></li>
                                <li><a href="category.php"><i class="menu-icon icon-tasks"></i> Create Category </a></li>
                                <li><a href="newbrand.php"><i class="menu-icon icon-tasks"></i>Brands </a></li>
                                <li><a href="insert-product.php"><i class="menu-icon icon-paste"></i>Insert Product </a></li>
                                <li><a href="manage-products.php"><i class="menu-icon icon-table"></i>Manage Products </a></li>
                        
                            </ul><!--/.widget-nav-->

						<ul class="widget widget-menu unstyled">
							<li><a href="registerShop.php"><i class="menu-icon icon-tasks"></i>Register Shop </a></l>
							<li><a href="user-logs.php"><i class="menu-icon icon-tasks"></i>User Login Log </a></li>
							<li><a href="change-password.php">Change Password</a></li>
							<li>
								<a href="logout.php">
									<i class="menu-icon icon-signout"></i>
									Logout
								</a>
							</li>
						</ul>

					</div><!--/.sidebar-->
				</div><!--/.span3-->
