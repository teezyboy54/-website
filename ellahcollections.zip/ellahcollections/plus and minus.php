<!DOCTYPE html>
<html>
<head>
	<title>plus and minus</title>
	<?php include('includes/head.php'); ?>
	<style type="text/css">
		$quantity-btn-color: #95d7fc;
.product {
	width: 30%;
	margin: 30px;
}
.form-group {
	width: 30%;
	margin: 30px;
	.glyphicon {
		color: $quantity-btn-color;
	}
}
	</style>
		<script type="text/javascript">
			
			function up(max) {
	    document.getElementById("myNumber").value = parseInt(document.getElementById("myNumber").value) + 1;
	    if (document.getElementById("myNumber").value >= parseInt(max)) {
	        document.getElementById("myNumber").value = max;
	    }
	}
	function down(min) {
	    document.getElementById("myNumber").value = parseInt(document.getElementById("myNumber").value) - 1;
	    if (document.getElementById("myNumber").value <= parseInt(min)) {
	        document.getElementById("myNumber").value = min;
	    }
	}

		</script>
</head>
<body>
    <img class="product" src="https://d2lm6fxwu08ot6.cloudfront.net/img-thumbs/960w/IP3VG5E0X8.jpg" alt="food">
    <div class="form-group">
        <label>Quantity: </label>
        <div class="input-group">
            <div class="input-group-btn">
                <button id="down" class="btn btn-default" onclick=" down('0')"><span class="glyphicon glyphicon-minus"></span></button>
            </div>
            <input type="text" id="myNumber" class="form-control input-number" value="1" />
            <div class="input-group-btn">
                <button id="up" class="btn btn-default" onclick="up('100')"><span class="glyphicon glyphicon-plus"></span></button>
            </div>
        </div>
    </div>
</body>
</html>