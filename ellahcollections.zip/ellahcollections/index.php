<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($con,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productPrice']);
			header('location:index.php');
		}else{
			$message="Product ID is invalid";
		}
	}
}


?>


<?php 
//for cart
 if(isset($_Get['action'])){
		if(!empty($_SESSION['cart'])){
		foreach($_POST['quantity'] as $key => $val){
			if($val==0){
				unset($_SESSION['cart'][$key]);
			}else{
				$_SESSION['cart'][$key]['quantity']=$val;
			}
		}
		}
	}
?>

<!DOCTYPE html>
<html lang="en">

	<?php include('includes/head.php'); ?>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<?php include('includes/top-header.php'); ?>
		<!-- /top Header -->

		<!-- header -->
		<?php  include('includes/main-header.php'); ?>
		
		<!-- container -->
	</header>
	<!-- /HEADER -->

	<!-- NAVIGATION ->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			
			<div id="responsive-nav">
				<!-- category nav -->
				<div class="category-nav" style="background: #e80505;">
					<span class="category-header" style="background: #e80505;">Categories <i class="fa fa-list"></i></span>
					<ul class="category-list">
						<?php 
						
						$sql=mysqli_query($con,"SELECT *  from category  ");

								while($row=mysqli_fetch_array($sql))
								{
									$id=$row['id'];
								   $sqll=mysqli_query($con,"SELECT *  from subcategory where categoryid=' $id'  ");
								    ?>
						<li class="dropdown side-dropdown">

							<a class="dropdown-toggle" data-tggle="dropdown" aria-expanded="true"  href="products.php?cid=<?php echo $row['id'];?>">
								<?php echo $row['categoryName'];?> <i clas="fa fa-angle-right"></i></a>
							<div class="custom-menu">
								<div class="row">
									<div class="col-md-4">
										<ul class="list-links">
											<h3 class="list-links-title"><?php echo $row['categoryName']; ?></h3></li>
											
										</ul>
										<hr class="hidden-md hidden-lg">
									</div>
									
								</div>
								
							</div>
						</li><?php } ?>
						
					</ul>
				</div>
				<!-- /category nav -->

				<!-- menu nav -->
				<?php //include('includes/main-nav-index.php'); ?>
				<!-- menu nav -->
			
		
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->




<!--Advert-->
	<!-- HOME -->
	<div id="home">
		<!-- container -->
		<div class="container">
			<!-- home wrap -->
			<div class="home-wrap">
				<!-- home slick -->
				<div id="home-slick">
					<!-- banner -->
					<div class="banner banner-1" >  
						<img style="width: 100%;  height: 60%;" src="./img/banner01.jpg" alt="" >
						<div class="banner-caption text-center">
							<h1>Clothing  sale</h1>
							<h3 class="white-color font-weak">Up to 50% Discount</h3>
							<button class="primary-btn">Shop Now</button>
						</div>
					</div>
					<!-- /banner -->

					<!-- banner -->
					<div class="banner banner-1">
						<img sstyle="width: 100%;  height: 60%;" src="./img/banner01.jpg" alt="" >
						<div class="banner-caption">
							<h1 class="primary-color">HOT DEAL<br><span class="white-color font-weak">Up to 50% OFF</span></h1>
							<button class="primary-btn">Shop Now</button>
						</div>
					</div>
					<!-- /banner -->

					
					
				</div>
				<!-- /home slick -->
			</div>
			<!-- /home wrap -->
		</div>
		<!-- /container -->
	</div></div>
	<!-- /HOME -->








	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				
				
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">


<!-- Male-->

				<!-- section title -->
				<div class="col-md-12">
					<div class="section-title">

						<h2 class="title" style="color: #e80505;"><?php $ret=mysqli_query($con,"SELECT category.categoryName as catname,products.* from products join category on category.id=products.category where category=8");
							if ($row=mysqli_fetch_array($ret)) 
							{ 
								echo $row['catname'];?>	
						</h2>
						<a href="products.php?cid=<?php echo  $row['category']; ?>" ><h4 style="color: #4040bd;">See More <?php } ?></h4></a>
						
					</div>
				</div>





			<!-- section title -->
                <div class="row">
                	<?php $ret=mysqli_query($con,"SELECT * from products where category=8 and productAvailability='In Stock' limit 6");
							while ($row=mysqli_fetch_array($ret)) 
							{ 
							?>
                    <div class="col-md-2 col-sm-4 col-xs-4">
								
								<div class="product product-single">
							<a href="product-page.php?pid=<?php echo htmlentities($row['id']);?>"><div class="product-thumb">
								<img style="width: 100%;  height: 160px;" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" data-echo="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" alt="" >
							</div></a>
							<div class="caption">
							<p><a href="product-page.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities(substr($row['productName'],0,10));?></a></p>

							<h5 class="product-price"> <?php echo "N ". htmlentities($row['productPrice']);?><span style="color: white;">.</span><del class="product-old-price"><?php if($row['productPriceBeforeDiscount']==0){}else{
						echo "N ".htmlentities($row['productPriceBeforeDiscount']);}?></del></h5>
														
						</div>
						</div>
						</div>
                <?php  } ?>
                   
                </div> 

			<!-- section title -->
				<div class="col-md-12">
					<div class="section-title">

						<h2 class="title" style="color: #e80505;"><?php $ret=mysqli_query($con,"SELECT category.categoryName as catname,products.* from products join category on category.id=products.category where category=9");
							if ($row=mysqli_fetch_array($ret)) 
							{ 
								echo $row['catname'];?>	
						</h2>
						<a href="products.php?cid=<?php echo  $row['category']; ?>" ><h4 style="color: #4040bd;">See More <?php } ?></h4></a>
						
					</div>
				</div>
			<!-- section title -->
                <div class="row">
                	<?php $ret=mysqli_query($con,"SELECT * from products where category=9 and productAvailability='In Stock' limit 6");
							while ($row=mysqli_fetch_array($ret)) 
							{ 
							?>
                    <div class="col-md-2 col-sm-4 col-xs-4">
								
								<div class="product product-single">
							<a href="product-page.php?pid=<?php echo htmlentities($row['id']);?>"><div class="product-thumb">
								<img style="width: 100%;  height: 160px;" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" data-echo="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" alt="" >
							</div></a>
							<div class="caption">
							<p><a href="product-page.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities(substr($row['productName'],0,10));?></a></p>

							<h5 class="product-price"> <?php echo "N ". htmlentities($row['productPrice']);?><span style="color: white;">.</span><del class="product-old-price"><?php if($row['productPriceBeforeDiscount']==0){}else{
						echo "N ".htmlentities($row['productPriceBeforeDiscount']);}?></del></h5>
														
						</div>
						</div>
						</div>
                <?php  } ?>
                   
                </div> </div>








<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>
<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>












































