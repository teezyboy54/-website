<?php 
session_start();
error_reporting(0);
include('includes/config.php');

 if(isset($_POST['LTrack'])){ 
 	$Track =$_POST['Track'];
    	if($Track==7161){
    		header("location:orders.php");
 	}else{
 		$_SESSION['track']="track";
 	}
 }

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>TRACK</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css" />
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<?php  include('includes/top-header.php'); ?>
		<!-- /top Header -->

		<!-- header -->
		<?php  include('includes/main-header.php'); ?>
		
		<!-- container -->
	</header>
	<!-- /HEADER -->

	

	<!-- NAVIGATION -->
	<?php include 'includes/main-nav.php'; ?>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="index.php">Home</a></li>
				<li class="active">Track</li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
					<div class="col-md-6">
						<div class="shiping-methods">
							<div class="section-title">
								<h4 class="title">TRACK YOUR ORDER</h4>
							</div>
							<div clas="input-checkbox">
								
								<label for="shipping-1" id="shipping-1"></label>

								<div class="caption">
									
									

										<form class="register-form outer-top-xs" method="post" > 
											<span style="color:red;" >

	</span>
										<div class="form-group">
										<h2>Please Enter Your Order ID <!--In The Box Below--></h2><br>
								<input class="input" type="text" required="required" name="Track" placeholder="Track ID" >
							</div>
							
							<input class="primary-btn" name="LTrack" type="submit" value="Track">
										<p>
								</div>
							</form>


<?php if(isset($_SESSION['track'])){ 
    
    	$Track =$_POST['Track'];
    	//if($Track!=7161){
    	
    	
$ret = mysqli_query($con,"SELECT * FROM ordertrackhistory WHERE orderId='$Track'");
$num=mysqli_num_rows($ret);
if($num>0)
{?>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">

    <tr height="50">
      <td colspan="2" class="fontkink2" style="padding-left:0px;"><div class="fontpink2"> <b><span style="color: green; font-size: 23px;">Order Tracking Details !</span></b></div></td>
      
    </tr>
    <tr height="30">
      <td  class="fontkink1"><b>order Id:</b></td>
      <td  class="fontkink" style="color: #e80505"><?php echo $Track;?></td>
    </tr>
	<?php 
while($row=mysqli_fetch_array($ret))
      {
     ?>
		
    
    
      <tr height="20">
      <td class="fontkink1" ><b>At Date:</b></td>
      <td  class="fontkink"><?php echo $row['postingDate'];?></td>
    </tr>
     <tr height="20">
      <td  class="fontkink1"><b>Status:</b></td>
      <td  class="fontkink" style="color: #e80505"><?php echo $row['status'];?></td>
    </tr>
    <!-- <tr height="20">
      <td  class="fontkink1"><b>Remark:</b></td>
      <td  class="fontkink"><?php echo $row['remark'];?></td>
    </tr>
-->
   
    <tr>
      <td colspan="2"><hr /></td>
    </tr>
   <?php } }
else{
   ?>
   <tr >
   <td colspan="2" ><span style="color: red;">Invalid Order ID</span></td>
   </tr>
   <?php  }
$st='Delivered';
   $rt = mysqli_query($con,"SELECT * FROM orders WHERE traking_id='$Track'");
     while($num=mysqli_fetch_array($rt))
     {
     $currrentSt=$num['orderStatus'];
   }
     if($st==$currrentSt)
     { ?>
   <tr><td colspan="2"><b>
      Product Delivered successfully </b></td>
   <?php } //} else{	$_SESSION['order']="orders";}
}
  ?>
</tr>
</table>
</div></div>
</div></div>

			<!-- /row -->
		</div>
		<!-- /container -->

	<!-- /section -->
	
<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>
<!-- /FOOTER -->


	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
