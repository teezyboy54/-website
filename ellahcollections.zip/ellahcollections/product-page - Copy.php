<?php 
session_start();
error_reporting(0);
include('includes/config.php');
//if(isset($_GET['action']) && $_GET['action']=="add"){
if(isset($_POST['addcart'])){
	$qtyCount=$_POST['qtyCount'];
	$id=$_POST['id'];
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity'][$qtyCount];
		header('location:product-page.php?pid='.$id);
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($con,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => $qtyCount, "price" => $row_p['productPrice']);
			header('location:product-page.php?pid='.$id);
		}else{
			$message="Product ID is invalid";
		}
	}
}
$pid=intval($_GET['pid']);
if(isset($_GET['pid']) && $_GET['action']=="wishlist" ){
	if(strlen($_SESSION['login'])==0)
    {   
header('location:login.php');
}
else
{
mysqli_query($con,"insert into wishlist(userId,productId) values('".$_SESSION['id']."','$pid')");
echo "<script>alert('Product aaded in wishlist');</script>";
header('location:my-wishlist.php');

}
}
if(isset($_POST['submit']))
{
	$qty=$_POST['quality'];
	$price=$_POST['price'];
	$value=$_POST['value'];
	$name=$_POST['name'];
	$summary=$_POST['summary'];
	$review=$_POST['review'];
	mysqli_query($con,"insert into productreviews(productId,quality,price,value,name,summary,review) values('$pid','$qty','$price','$value','$name','$summary','$review')");
}






?>


<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php'); ?>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<?php  include('includes/top-header.php'); ?>
		<!-- /top Header -->

		<!-- header -->
		<?php  include('includes/main-header.php'); ?>
		
		<!-- container -->
	</header>
	<!-- /HEADER -->

	

	<!-- NAVIGATION -->
	<?php include 'includes/main-nav.php'; ?>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			
			<?php
								$ret=mysqli_query($con,"SELECT category.categoryName as catname,subCategory.subcategory as subcatname,products.* from products join category on category.id=products.category join subcategory on subcategory.id=products.subCategory where products.id='$pid'");
								while ($rw=mysqli_fetch_array($ret)) {

								?>
							<ul class="breadcrumb">

								<li><a href="index.php">Home</a></li>
								<li><a href="products.php?cid=<?php echo  $rw['category']; ?>"><?php echo htmlentities($rw['catname']);?></a></li>
								<li><a href="subcategory-products.php?sid=<?php echo $rw['subCategory']; ?>"><?php echo htmlentities($rw['subcatname']);?></a></li>
								<!--<li><a href="checkout.php"><?php echo htmlentities($rw['pname']);?></a></li>-->
								<li><a href="#"><?php echo htmlentities($rw['productName']);?></a></li>
							</ul><?php }?>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!--  Product Details -->
				<?php 
//$update_views_count = "UPDATE products set post_views_count=post_views_count+1 WHERE id='$pid'";
//mysqli_query($con,$update_views_count);
$ret=mysqli_query($con,"select * from products where id='$pid'");
while($row=mysqli_fetch_array($ret))
{

?>
				<div class="product product-details clearfix">
					<div class="col-md-6">
						<div id="product-main-view">
							<div class="product-view">

								<img style="width: 100%"  class="img-responsive" alt="" data-echo="assets/images/blank.gif" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" width="370" height="350" />
							</div>
							<div class="product-view">
								<img style="width: 100%" class="img-responsive" alt="" data-echo="assets/images/blank.gif" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage2']);?>" width="370" height="350" />
							</div>
							<div class="product-view">
								<img style="width: 100%" class="img-responsive" alt="" data-echo="assets/images/blank.gif" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage3']);?>" width="370" height="350" />
							</div>
							<div class="product-view">
								<img style="width: 100%" class="img-responsive" alt="" data-echo="assets/images/blank.gif" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage2']);?>" width="370" height="350" />
							</div>
						</div>
						<div id="product-view">
							<div class="product-view">
								<img style="width: 100%" class="img-responsive" alt="" data-echo="assets/images/blank.gif" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" width="370" height="350" />
							</div>
							<div class="product-view">
								<img style="width: 100%" class="img-responsive" alt="" data-echo="assets/images/blank.gif" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage2']);?>" width="370" height="350" />
							</div>
							<div class="product-view">
								<img style="width: 100%" class="img-responsive" alt="" data-echo="assets/images/blank.gif" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage3']);?>" width="370" height="350" />
							</div>
							<div class="product-view">
								<img style="width: 100%" class="img-responsive" alt="" data-echo="assets/images/blank.gif" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage2']);?>" width="370" height="350" />
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="product-body">
							
							<h2 class="product-name"><?php echo htmlentities($row['productName']);?></h2>
							<h3 class="product-price">N <?php echo htmlentities($row['productPrice']);?><span style="color: white;">.	</span>

								<?php if($row['productPriceBeforeDiscount']==0)
											{
												echo " ";
											}
											else
											{
												echo "<del class='product-old-price'>N ". htmlentities($row['productPriceBeforeDiscount'])."</del>";
											}

											?>

							</h3>
					
							<p><strong>Availability:</strong> <span style="color: #e80505;"><?php echo htmlentities($row['productAvailability']);?></span></p>
							<p><strong>Brand:</strong><span style="color: #e80505;"><?php echo htmlentities($row['productCompany']);?></span></p>
												
							<p><?php //echo $row['productDescription'];?></p>
							

							<div class="product-btns">
								<div class="qty-input">
									<a href="#" ><button class="primary-btn add-to-cart"><i class="fa fa-call"></i> Call 0903453444</button></a><br><br>
									
								</div><br>

								


								<?php 
									//if($row['shopId']!=5){
								?>
							<form method="Post" action="product-page.php">
							<div class="form-group">
						        <div class="input-group" style="width: 112px;">
						            <div class="input-group-btn">
						                <span id="down" class="btn btn-default" onclick=" down('0')"><span class="glyphicon glyphicon-minus" ></span></span>
						            </div>
						            <input type="text" id="myNumber"  class="form-control input-number" value="1" name="qtyCount" />
						            <div class="input-group-btn">
						                <span id="up" class="btn btn-default" onclick="up('100')"><span class="glyphicon glyphicon-plus"  ></span></span>
						            </div>
						        </div>
						    </div>
						            <input type="hidden"   class="form-control input-number" value="<?php echo $row['id'];?>" name="id" />

									<input type="submit" name="addcart" value="Add to Cart" class="primary-btn add-to-cart"> <!--</a>-->
								</form>
								<?php 	//} ?>
								<script type="text/javascript">
			
			function up(max) {
	    document.getElementById("myNumber").value = parseInt(document.getElementById("myNumber").value) + 1;
	    if (document.getElementById("myNumber").value >= parseInt(max)) {
	        document.getElementById("myNumber").value = max;
	    }

	}
	
	function down(min) {
	    document.getElementById("myNumber").value = parseInt(document.getElementById("myNumber").value) - 1;
	    if (document.getElementById("myNumber").value <= parseInt(min)) {
	        document.getElementById("myNumber").value = min;
	    }
	}
	function Charge(val){
		var textbox= document.getElementById('myNumber');
		var textboxname =textbox.name;
		location.href='includes/increment.php?inc='+textboxname;
	}
//location.href='includes/increment.php';
		</script>
								<div class="pull-right"><!--you can introduce </div> to bring the description down-->


							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="product-tab">
							<ul class="tab-nav">
								<li class="active"><a data-toggle="tab" href="#tab1">Description</a></li>
								<!--<li><a data-toggle="tab" href="#tab1">More Products</a></li>-->
								<li><a data-toggle="tab" href="#tab2"><S!--Reviews (3)--></a></li>
							</ul>
							<div class="tab-content">
								<div id="tab1" class="tab-pane fade in active">
									<p> <?php echo htmlentities( $row['productDescription']); ?></p>
								</div>
								<div id="tab2" class="tab-pane fade in">

									<div class="row">
										<div class="col-md-6">
											<div class="product-reviews">
												

												<div class="single-review">
													<div class="review-heading">
														<div><a href="#"><i class="fa fa-user-o"></i> Evans</a></div>
														<div><!--<a href="#"><i class="fa fa-clock-o"></i> 27 DEC 2020 / 8:0 PM</a>--></div>
														<div class="review-rating pull-right">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o empty"></i>
														</div>
													</div>
													<div class="review-body">
														<p><?php echo $row['productName']; ?></p>
													</div>
												</div>

											</div>
										</div>
										<div class="col-md-6">
											<h4 class="text-uppercase">Write Your Review</h4>
											<p>Your email address will not be published.</p>
											<form class="review-form" action="index.php">
												<div class="form-group">
													<input class="input" type="text" required placeholder="Your Name" />
												</div>
												<div class="form-group">
													<input class="input" type="email" required placeholder="Email Address" />
												</div>
												<div class="form-group">
													<textarea class="input" required placeholder="Your review"></textarea>
												</div>
												<div class="form-group">
													<div class="input-rating">
														<strong class="text-uppercase">Your Rating: </strong>
														<div class="stars">
															<input type="radio" id="star5" required name="rating" value="5" /><label for="star5"></label>
															<input type="radio" id="star4" name="rating" value="4" /><label for="star4"></label>
															<input type="radio" id="star3" name="rating" value="3" /><label for="star3"></label>
															<input type="radio" id="star2" name="rating" value="2" /><label for="star2"></label>
															<input type="radio" id="star1" name="rating" value="1" /><label for="star1"></label>
														</div>
													</div>
												</div>
													<input type="submit" value="Submit" class="primary-btn" name="">
											</form>
										</div>
									</div>



								</div>
							</div>
						</div>
					</div>

				</div>
				<!-- /Product Details -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- section -->
	<?php $cid=$row['category'];
	$subcid=$row['subCategory']; } ?>
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- section title -->
				<div class="col-md-12">
					<div class="section-title">
						<h2 class="title">RELATED PRODUCT(S)</h2>
					</div>
				</div>
				<!-- section title -->

				<!-- Product Single -->

				<?php 
$qry=mysqli_query($con,"SELECT * from products where (subCategory='$subcid')AND id <>'$pid' ");
while($row=mysqli_fetch_array($qry))
{

			?>
				<div class="col-md-2 col-sm-4 col-xs-4">
					<div class="product product-single">
						<a href="product-page.php?pid=<?php echo htmlentities($row['id']);?>"><div class="product-thumb">
							<img style="width: 100%; height:160px;" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" data-echo="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" alt="" >
						</div></a>
						<div class="product-body">
							
							
							<p class="product-name"><a href="product-page.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities(substr($row['productName'],0,10));?></a></p>
							<h3 class="product-price">N <?php echo htmlentities($row['productPrice']);?><span style="color: white;">.	</span><?php if($row['productPriceBeforeDiscount']==0)
											{
												echo " ";
											}
											else
											{
												echo "<del class='product-old-price'>N ". htmlentities($row['productPrice'])."</del>";
											}

											?></h3>
							
						</div>
					</div>
				</div><?php } ?>
				<!-- /Product Single -->

				
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->


<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>
<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script sc="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
