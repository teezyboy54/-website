-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql211.epizy.com
-- Generation Time: Mar 03, 2021 at 02:08 PM
-- Server version: 5.6.48-88.0
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_25543042_dornu`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `Owner` varchar(50) NOT NULL,
  `ShopName` varchar(50) NOT NULL,
  `Location` varchar(50) NOT NULL,
  `phone1` varchar(20) NOT NULL,
  `phone2` varchar(30) NOT NULL,
  `dealing` varchar(50) NOT NULL,
  `shop` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `Owner`, `ShopName`, `Location`, `phone1`, `phone2`, `dealing`, `shop`, `password`, `b`, `creationDate`, `updationDate`) VALUES
(1, 'admin@razki.com', '', '', '', '', '', '', 0, '$2y$10$sExExCfmQppJA6oD76dT2.XmCn8kLIa2ihIpV4/L8EnoTijHuZcfe', 'aa', '2017-01-24 16:21:18', '21-06-2018 08:27:55 PM'),
(5, 'sgm@razki.com', 'kj', 'sgm', 'Ho', '9999', '999', 'jkj', 1, '$2y$10$DvvGbKZc3c/eyFt1Qrnk7eG7bWRsPSCB0NM8nsOxFAOpsz8TYMN9G', 'aa', '2020-03-02 00:32:39', '');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(255) DEFAULT NULL,
  `categoryDescription` longtext,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `creationDate`, `updationDate`) VALUES
(8, 'Groceries', 'Groceries', '2020-03-07 09:25:01', NULL),
(9, ' Drinks ', ' Drinks ', '2020-03-08 01:24:14', NULL),
(10, 'Ingredients', 'Ingredients', '2020-03-10 14:28:32', NULL),
(11, 'HOME ESSENTIALS', 'HOME ESSENTIALS', '2020-03-10 14:50:17', NULL),
(12, 'SNACKS & BRANDED FOODS', 'SNACKS & BRANDED FOODS', '2020-03-10 15:04:47', NULL),
(13, 'Beauty & Personal Care', 'Beauty & Personal Care', '2020-03-15 23:12:14', NULL),
(14, 'Baby', 'Baby', '2020-03-16 02:09:40', NULL),
(15, 'Beverage', 'liquid ', '2020-04-03 14:51:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `id` int(11) NOT NULL,
  `AgentId` int(11) NOT NULL,
  `FullName` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL,
  `phone1` varchar(30) NOT NULL,
  `phone2` varchar(30) NOT NULL,
  `DigitalAddress` varchar(30) NOT NULL,
  `GuardianName` varchar(30) NOT NULL,
  `GuardianNumber` varchar(30) NOT NULL,
  `GuardianDigital` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `deliverycode`
--

CREATE TABLE `deliverycode` (
  `id` int(11) NOT NULL,
  `AgentId` varchar(30) NOT NULL,
  `orderid` varchar(30) NOT NULL,
  `code` varchar(30) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deliverycode`
--

INSERT INTO `deliverycode` (`id`, `AgentId`, `orderid`, `code`, `date`) VALUES
(1, '34', '34', '34', '2020-01-25 03:40:00'),
(2, '34', '34', '34', '2020-01-25 06:53:48'),
(3, '22', '34', '34', '2020-01-25 06:54:41'),
(4, '34', '34', '34', '2020-01-25 06:55:51'),
(5, '22', '34', '34', '2020-01-25 06:56:18'),
(6, '22', '34', '34', '2020-01-25 06:58:33');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `tracking_id` varchar(255) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `shippingCharge` double NOT NULL,
  `orderDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `paymentMethod` varchar(50) DEFAULT NULL,
  `orderStatus` varchar(55) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `tracking_id`, `userId`, `productId`, `quantity`, `shippingCharge`, `orderDate`, `paymentMethod`, `orderStatus`) VALUES
(104, 'SGM-590418', 7, '29', 1, 5.475, '2020-04-15 16:36:59', NULL, NULL),
(105, 'SGM-590418', 7, '41', 1, 5.475, '2020-04-15 16:37:01', NULL, NULL),
(106, 'SGM-421684', 7, '29', 1, 5.475, '2020-04-15 16:37:03', NULL, NULL),
(107, 'SGM-421684', 7, '41', 1, 5.475, '2020-04-15 16:37:05', NULL, NULL),
(108, 'SGM-324963', 7, '65', 1, 5, '2020-04-16 10:07:00', NULL, NULL),
(109, 'SGM-509009', 7, '64', 1, 6.02, '2020-04-16 11:16:15', NULL, NULL),
(110, 'SGM-509009', 7, '72', 1, 6.02, '2020-04-16 11:16:17', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ordertrackhistory`
--

CREATE TABLE `ordertrackhistory` (
  `id` int(11) NOT NULL,
  `orderId` varchar(30) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `remark` mediumtext,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordertrackhistory`
--

INSERT INTO `ordertrackhistory` (`id`, `orderId`, `status`, `remark`, `postingDate`) VALUES
(1, 'D3584', 'in Process', 'In Process\r\n', '2020-04-15 09:05:50'),
(2, 'D3584', 'Delivered', 'd', '2020-04-15 09:06:05'),
(3, 'D3053', 'in Process', 's', '2020-04-15 09:13:22'),
(4, 'D3053', 'Delivered', 'c', '2020-04-15 09:14:00'),
(5, 'D6248', 'in Process', 'd', '2020-04-15 11:54:44');

-- --------------------------------------------------------

--
-- Table structure for table `productreviews`
--

CREATE TABLE `productreviews` (
  `id` int(11) NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `review` longtext,
  `reviewDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productreviews`
--

INSERT INTO `productreviews` (`id`, `productId`, `quality`, `price`, `value`, `name`, `summary`, `review`, `reviewDate`) VALUES
(2, 3, 4, 5, 5, 'Anuj Kumar', 'BEST PRODUCT FOR ME :)', 'BEST PRODUCT FOR ME :)', '2017-02-26 20:43:57'),
(3, 3, 3, 4, 3, 'Sarita pandey', 'Nice Product', 'Value for money', '2017-02-26 20:52:46'),
(4, 3, 3, 4, 3, 'Sarita pandey', 'Nice Product', 'Value for money', '2017-02-26 20:59:19');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `subCategory` int(11) DEFAULT NULL,
  `shopId` int(11) NOT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `productCompany` varchar(255) DEFAULT NULL,
  `productPrice` varchar(20) DEFAULT NULL,
  `productPriceBeforeDiscount` varchar(50) DEFAULT NULL,
  `productDescription` text,
  `productImage1` varchar(255) DEFAULT NULL,
  `productImage2` varchar(255) DEFAULT NULL,
  `productImage3` varchar(255) DEFAULT NULL,
  `shippingChargeq` varchar(50) DEFAULT NULL,
  `productAvailability` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `subCategory`, `shopId`, `productName`, `productCompany`, `productPrice`, `productPriceBeforeDiscount`, `productDescription`, `productImage1`, `productImage2`, `productImage3`, `shippingChargeq`, `productAvailability`, `postingDate`, `updationDate`) VALUES
(26, 8, 45, 5, 'Nescafe Classic 50G Coffee Tin', 'Nestle', '8.5', '0', '', 'Nestle-Nescafe-50g-Tin-500x500.jpg', 'Nestle-Nescafe-50g-Tin-500x500.jpg', 'Nestle-Nescafe-50g-Tin-500x500.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-08 01:58:24', NULL),
(27, 8, 18, 5, 'Cerelac 400g Tin Millet', 'Nestle', '13.5', '0', 'CERELAC is an infant cereal with milk for complementary feeding of babies from 6 months. CERELAC is fortified Iron, Zinc, Iodine and Vitamins to cover the high nutritional needs of babies at the critical age of rapid growth and development, to support brain and cognitive development. It also contains Bifidus BL which supports babiesâ€™ natural defenses. Types: CERELAC Maize, CERELAC Wheat, CERELAC Rice, CERELAC Millet, and CERELAC Yummy Fruits.', 'carelac 400g millet mil 11.jpg', 'carelac 400g millet mil 2.jpg', 'carelac 400g millet mil.jpg', '0', 'In Stock', '2020-03-08 02:18:56', NULL),
(28, 8, 18, 5, 'YUMVITA INFANT CEREAL MAIZE WHEAT 400G', 'Promasidor', '13.00', '0', 'Net Weight: 400g\r\nInfant Cereal With Milk\r\nFor 6 Months & Over\r\nVitamins & Minerals\r\nHelps Brain Development\r\nEasy To Digest Formula', 'YUMVITA  WHEAT 400G 1.jpg', 'YUMVITA INFANT CEREAL WHEAT TIN 400G.jpg', 'YUMVITA  WHEAT 400G 1.jpg', '0', 'In Stock', '2020-03-08 02:28:20', NULL),
(29, 8, 45, 5, 'Nestle Coffee Mate - 1kg Tin', 'Nestle', '14.5', '0', 'Nestle Coffee Mate - 1kg Tin', 'Nestle Coffee Mate - 1kg Tin.jpg', 'Nestle Coffee Mate - 1kg Tin 2.jpg', 'Nestle Coffee Mate - 1kg Tin11.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-08 02:33:20', NULL),
(30, 8, 17, 5, 'Cowbell Semi Skimmed Milk 400g Tin', 'Promasidor', '22.00', '0', 'Net Weight: 400g\r\n\r\nInstant Semi-Skimmed Filled Milk Powder\r\n\r\nMade From Fresh Skimmed Cows\' Milk & Vegetable Fat\r\n\r\nCholesterol Free\r\n\r\nContains Proteins, Calcium, Vitamins & Minerals\r\n\r\nEssential Nutrients For The Whole Family', 'cowbell-sem-skimmed-milk-400g-tin.png', 'cowbell-sem-skimmed-milk-400g-tin.jpg', 'cowbell-sem-skimmed-milk-400g-tin.jpg', '0', 'In Stock', '2020-03-08 02:47:44', NULL),
(31, 8, 17, 5, 'Cowbell 400G Milk Powder Tin ', 'Promasidor', '22.50', '0', 'Cowbell Tin 400g,Our Milk, is delicious, nutritious and tatses just like fresh milk. Cowbell is specially made with fresh skimmed cows\' milk and vegetable fat, which contains no cholesterol.\r\n\r\ncowbell contains the proteins, calcium,vitamins & minerals essential for the whole family.', 'Cowbell 400G Milk Powder Tin 1.jpg', 'Cowbell 400G Milk Powder Tin.jpg', 'Cowbell 400G Milk Powder Tin 1.jpg', '0', 'In Stock', '2020-03-08 03:00:50', NULL),
(32, 8, 45, 5, 'Nestle Nido', 'Nestle', '32.00', '0', 'It is a nutritious milk, specially formulated for growing children from the age of 2 years onwards. Fortified with 25 essential nutrients', 'nido.jpeg', 'nido.jpeg', 'nido.jpeg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-08 03:08:54', NULL),
(33, 8, 45, 5, 'NIDO 1+', 'Nestle', '30.00', '0', 'This powdered milk beverage with a delicious honey flavor has 13 vitamins and minerals to help support your toddlerâ€™s healthy growth and development. For 1-3 years', 'nido-1-plus-1-3-years-400g.jpg', 'nido-1-plus-1-3-years-400g.jpg', 'nido-1-plus-1-3-years-400g.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-08 03:11:58', NULL),
(34, 8, 45, 5, 'MARVEL ORIGINAL SKIMMED MILK POWDER MADE IN UK â€“ 350g', 'MARVEL ORIGINAL', '30.00', '0', 'Naturally calcium rich.\r\nGreat with tea and coffee.\r\nLess than 1% fat.\r\nIdeal for bread makers and cooking.\r\nWith vitamins A + D.\r\nLess than 1% fat, Source of calcium, vitamin A and D, High protein, Great in tea and coffee, Use in bread makers & cooking, Suitable for vegetarians.', 'marvel orginal skimmes milk powder.jpg', 'marvel orginal skimmes milk powder.jpg', 'marvel orginal skimmes milk powder.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-08 03:23:53', NULL),
(35, 8, 18, 5, 'SMA GOLD PREMIUM FOLLOW-ON MILK (2) 6-12 MONTHS - 400G', 'SMA', '45.00', '0', 'SMA GOLD 2 6-12 MONTHS - 400G\r\nSMA Follow-On Milk with Nutri-Steps to be used as part of a mixed weaning diet.\r\nNourishing their growth and development\r\nNutri-Steps is our unique blend of ingredients tailored to help support babies nutritional needs now, and as they grow, every step of the way.\r\nCognition: Fortified with Iron to help support normal cognitive development\r\nGrowth: With Omega 3 & 6 to support normal development and growth†\r\nDevelopment: With Vitamin D and Calcium to support the normal growth and development of bones', 'sma-gold-2-6-12-months-400g.jpg', 'sma-gold-2-6-12-months-400g.jpg', 'sma-gold-2-6-12-months-400g.jpg', '0', 'In Stock', '2020-03-08 03:30:11', NULL),
(36, 8, 18, 5, 'Nestle Lactogen 1 400g', 'Nestle', '25.00', '0', 'Nestle - Lactogen Stage 1 Follow - Up Infant Formula - 400g\r\nNan Lactogen 1 Starter Infant Formula is suitable for infants from birth to 6 months. \r\n\r\nIngredients & Allergen Info:\r\nIngredients: Skimmed Milk Powder (cowâ€™s milk) (protein source), Whey Protein (cowâ€™s milk) (protein source), Maltodextrin, Vegetable Oil (Palm Fruit, Rapeseed, Coconut, Sunflower Seed), Sucrose, Soya Lecithin, Calcium Citrate, Magnesium Chloride, Potassium Citrate, Potassium Chloride, Vitamins (A, B1, B2, B6, B12, C, D3, E, K1, Niacin, Biotin, Folic Acid, Pantothenic Acid), Ferrous Sulphate, Zinc Sulphate, Probiotic 106 CFU/g (Lactobacillus reuteri culture), Copper Sulphate, Lactose, Potassium Iodide, Sodium Selenate.', 'lactogen.jpg', 'lactogen.jpg', 'lactogen.jpg', '0', 'In Stock', '2020-03-08 03:36:40', NULL),
(37, 8, 18, 5, '3 x Nestle Lactogen 2 400g', 'Nestle', '25.00', '0', 'Nestle Lactogen Follow-up formula in powder with iron , from 6 to 12 months', 'lactogen 2.png', 'lactogen 2.png', 'lactogen 2.png', '0', 'In Stock', '2020-03-08 03:39:35', NULL),
(38, 8, 17, 5, 'Nestle Nan Optipro 1 Premium Starter Infant Formula 400g', 'Nestle', '35.00', '0', 'Nestle Nan Infant Formula NAN has provided us with Pre NAN, by Nestle, a special formula for our preterm little ones. With an included new, easy scoop, feeding is easy and quick for your precious little one! And as your little one gets bigger, continue on with NAN formula stage 1, 2, and 3.', 'Nestle Nan Optipro 1 Premium Starter Infant Formula 400g.jpeg', 'Nestle Nan Optipro 1 Premium Starter Infant Formula 400g.jpeg', 'Nestle Nan Optipro 1 Premium Starter Infant Formula 400g.jpeg', '0', 'In Stock', '2020-03-08 03:43:17', NULL),
(39, 8, 18, 5, 'INFACARE 400G GROWING UP MILK FORMULA 3', ' Infacare', '30.00', '0', 'The best price of INFACARE 400G GROWING UP MILK FORMULA 3 by Foodplus in Kenya is 1,075 KSh\r\nAvailable payment methods areCash on DeliveryCredit Card\r\nDelivery fees are 0-250 KSh, with delivery expected within 1 day(s)\r\nSimilar products to INFACARE 400G GROWING UP MILK FORMULA 3 are sold at E Mart with prices starting at 1,200 KSh\r\nThe first appearance of this product was on Oct 09, 2016', 'INFACARE 400G GROWING UP MILK FORMULA 3.jpg', 'INFACARE 400G GROWING UP MILK FORMULA 3.jpg', 'INFACARE 400G GROWING UP MILK FORMULA 3.jpg', '0', 'In Stock', '2020-03-08 03:46:47', NULL),
(40, 8, 17, 5, 'Infacare Follow-on Formula 2 (400g)', 'Infacare', '30.00', '0', 'Follow on formula 2\r\nFrom 6-12 months\r\n900g', 'Infacare Follow-on Formula 2 (400g).jpg', 'Infacare Follow-on Formula 2 (400g).jpg', 'Infacare Follow-on Formula 2 (400g).jpg', '0', 'In Stock', '2020-03-08 03:50:56', NULL),
(41, 8, 45, 5, 'Aptamil 2 Follow On Milk Powder 900G', 'Aptamil', '95.00', '0', 'Aptamil with Pronutra+ is a follow on milk thatâ€™s nutritionally tailored to complement a weaning diet. Contains unique blend of nutrients, most advanced formula.\r\n\r\nAptamil with Pronutra+ Follow On milk complements a varied and balanced weaning diet, with a blend of Galacto- and Fructo-oligosaccharides - Long Chain Polyunsaturated fatty acids, DHA (Omega 3) to support normal visual development, the beneficial effect is obtained with a daily intake of 100mg of DHA - Vitamins A, C, & D - Iron to support normal cognitive development,', 'Aptamil 2 Follow On Milk Powder 900G.jpg', 'Aptamil 2 Follow On Milk Powder 900G.jpg', 'Aptamil 2 Follow On Milk Powder 900G.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-08 03:59:37', NULL),
(42, 8, 21, 5, 'Milk Soda Cracker 100g', 'Feng Wei Yuan', '2.6', '0', '- Product Code: CONFECTIONERY_0266\r\n- Availability: 50', 'IMG_0893.JPG', 'IMG_0895.JPG', 'IMG_0894.JPG', '0', 'In Stock', '2020-03-09 00:19:43', NULL),
(43, 8, 21, 5, 'Milk Soda Cracker 248g', 'Milk Soda Cracker 248g', '5.00', '0', 'Milk Soda Cracker 248g', 'IMG_0889.JPG', 'IMG_0897.JPG', 'IMG_0891.JPG', '0', 'In Stock', '2020-03-09 00:29:07', NULL),
(44, 8, 21, 5, 'London Oats Digestive Biscuit 100g', 'McBerry', '2.00`', '0', 'London Oats Digestive Biscuit 100g', 'IMG_0947.JPG', 'IMG_0949.JPG', 'IMG_0948.JPG', '0', 'In Stock', '2020-03-09 01:40:46', NULL),
(45, 8, 21, 5, 'Fun Power Chocolate Cookies 12 packs', 'H &H ', '13.50', '0', 'Fun Power Chocolate Cookies 12 packs', 'IMG_0903.JPG', 'IMG_0905.JPG', 'IMG_0904.JPG', '0', 'In Stock', '2020-03-09 02:12:30', NULL),
(46, 8, 21, 5, 'Merryland cookies minis 175g', 'B&M Stores', '9.50', '0', 'Best Before : 06/2019\r\nMaryland Cookies Minis 175g\r\n\r\nNo Artificial Colours\r\n\r\nNo Artificial Flavours\r\n\r\nNo Artificial Sweeteners\r\n\r\nNo Artificial Preservatives\r\n\r\nNon GM Ingredients\r\n\r\nNo Hydrogenated Fats\r\n\r\nSuitable for Vegetarians', 'IMG_0931.JPG', 'IMG_0933.JPG', 'IMG_0932.JPG', '0', 'In Stock', '2020-03-09 03:32:04', NULL),
(47, 8, 21, 5, 'Marit Biscuits 400g', 'CBL Munchee', '8.5', '0', 'Marit Biscuits 400g', 'IMG_0911.JPG', 'IMG_0912.JPG', 'IMG_0913.JPG', '0', 'In Stock', '2020-03-09 03:46:35', NULL),
(48, 8, 45, 5, 'Nescafe Classic 200g', 'Nestle', '32.00', '0', '', 'Nestle-Nescafe-200g-Tin-1-228x228.jpg', 'IMG_0795.jpg', 'IMG_0794.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-09 03:55:37', NULL),
(49, 8, 21, 5, 'Cream Bite Pineapple Flavoured Biscuit', 'Lele', '2.5', '0', 'Cream Bite Pineapple Flavoured Biscuit', 'IMG_0935.JPG', 'IMG_0936.JPG', 'IMG_0937.JPG', '0', 'In Stock', '2020-03-09 04:14:50', NULL),
(50, 8, 21, 5, 'Chipsletten 100g', 'Lorenz', '9.00', '0', 'Chipsletten 100g', 'IMG_0967.JPG', 'IMG_0968.JPG', 'IMG_0967.JPG', '0', 'In Stock', '2020-03-09 19:37:42', NULL),
(51, 9, 23, 5, 'Baileys The Original Irish Cream 1L', 'Baileys', '26.00', '0', 'The perfect marriage of fresh, premium Irish dairy cream, the finest spirits, aged Irish whiskey, and a unique chocolate blend.\r\nCategory	Liqueur\r\nRegion	Ireland\r\nBrand	Baileys\r\nAlcohol/vol	17%\r\nProof	34.00', 'IMG_1508.JPG', 'IMG_1509.JPG', 'IMG_1508.JPG', '0', 'In Stock', '2020-03-09 19:45:41', NULL),
(52, 9, 23, 5, 'Bardinet French Brandy Vsop 100cl', 'VSOP French Brandy', '36.00', '0', 'Bardinet French Brand Vsop 100cl', 'IMG_1502.JPG', 'IMG_1503.JPG', 'IMG_1502.JPG', '0', 'In Stock', '2020-03-09 20:02:34', NULL),
(53, 9, 23, 5, 'Beefeater London Dry Gin 1L, 41%', 'Beefeater', '63.00', '0', 'Beefeater London Dry Gin 1L, 41%', 'IMG_1533.JPG', 'IMG_1534.JPG', 'IMG_1533.JPG', '0', 'In Stock', '2020-03-09 20:08:36', NULL),
(54, 9, 26, 5, 'Dominion communion 750 ml  Non Alcoholic', 'Dominion communion ', '5.50', '0', 'Dominion communion 750 ml  Non Alcoholic', 'IMG_1558.JPG', 'IMG_1559.JPG', 'IMG_1560.JPG', '0', 'In Stock', '2020-03-09 20:12:20', NULL),
(55, 9, 24, 5, 'Malta Guinnes 12 bottle', 'Guinnes ', '30.00', '0', 'Malta Guinnes 12 bottle', 'IMG_1592.JPG', 'IMG_1593.JPG', 'IMG_1592.JPG', '0', 'In Stock', '2020-03-09 20:15:45', NULL),
(56, 9, 23, 5, 'Gold Napoleon 40%', 'Napoleon ', '19.50', '0', 'Gold Napoleon 40%', 'IMG_1549.JPG', 'IMG_1550.JPG', 'IMG_1549.JPG', '0', 'In Stock', '2020-03-09 20:22:21', NULL),
(57, 9, 23, 5, 'Old Admiral Vsop brand 750ml 40%', 'Vsop ', '17.50', '0', 'Old Admiral Vsop brand 750ml 40%', 'IMG_1505.JPG', 'IMG_1506.JPG', 'IMG_1505.JPG', '0', 'In Stock', '2020-03-09 20:26:11', NULL),
(58, 9, 23, 5, 'Chevalier Vsop 36% 1L', 'Napoleon ', '24.00', '0', 'Chevalier Vsop 36% 1L', 'IMG_1543.JPG', 'IMG_1544.JPG', 'IMG_1543.JPG', '0', 'In Stock', '2020-03-09 20:29:21', NULL),
(59, 9, 23, 5, 'XO French Brandy Bardinet 40% 70cl', 'Bardinet ', '48.00', '0', 'XO French Brandy Bardinet 40% 70cl', 'IMG_1494.JPG', 'IMG_1495.JPG', 'IMG_1496.JPG', '0', 'In Stock', '2020-03-09 20:32:35', NULL),
(60, 9, 24, 5, 'Strawberry Drink 0.5l', 'incolac', '7.20', '0', 'Strawberry Drink 0.5l', 'IMG_1459.JPG', 'IMG_1460.JPG', 'IMG_1461.JPG', '0', 'In Stock', '2020-03-09 20:37:44', NULL),
(61, 9, 23, 5, 'Smirnoff thiple distilles ten times fiterred vodka', 'Smirnoff', '12.00', '0', 'Smirnoff thiple distilles ten times fiterred vodka', 'IMG_1511.JPG', 'IMG_1512.JPG', 'IMG_1511.JPG', '0', 'In Stock', '2020-03-09 20:44:32', NULL),
(62, 9, 27, 5, 'Cranberry Blackcurrant Juice', 'Ocean Spary', '11.00', '0', 'Cranberry Blackcurrant Juice', 'IMG_1463.JPG', 'IMG_1464.JPG', 'IMG_1465.JPG', '0', 'In Stock', '2020-03-09 20:49:41', NULL),
(63, 10, 31, 5, 'Frytol 3L Vegetable Cooking Oil', 'Frytol ', '33.50', '0', 'Frytol 3L Vegetable Cooking Oil', '28_2__3.jpg', '28_2__3.jpg', '28_2__3.jpg', '0', 'In Stock', '2020-03-10 14:36:31', NULL),
(64, 10, 31, 5, 'Lele 5L Cooking Oil ', 'Lele', '56.00', '0', 'Lele Cooking Oil 5L', 'LELE-SUNFLOWER-OIL-5LPNG-1512458802.png', 'LELE-SUNFLOWER-OIL-5LPNG-1512458802.png', 'LELE-SUNFLOWER-OIL-5LPNG-1512458802.png', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-10 14:38:45', NULL),
(65, 10, 31, 5, 'frytol 5L Cooking Oil ', 'frytol ', '50.00', '0', 'frytol Cooking Oil 5L', 'frytol.jpg', 'frytol.jpg', 'frytol.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-10 14:40:30', NULL),
(66, 10, 31, 5, 'Huile 3L Bonita Cooking Oil ', 'Huile Bonita', '38.50', '0', 'Huile Bonita Cooking Oil 3L', 'huile_bonita_3_l_500x.jpg', 'huile_bonita_3_l_500x.jpg', 'huile_bonita_3_l_500x.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-10 14:41:42', NULL),
(67, 10, 31, 5, 'Huile 5L Bonita Cooking Oil', 'Huile Bonita ', '76.50', '0', 'Huile Bonita Cooking Oil 5L', 'huile_bonita_5l_500x.jpg', 'huile_bonita_5l_500x.jpg', 'huile_bonita_5l_500x.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-10 14:42:57', NULL),
(68, 10, 31, 5, 'FRYTOL 1L Cooking Oil ', 'Frytol ', '12.50', '0', 'FRYTOL Cooking Oil 1L', 'Frytol-oil-1L-600x600.png', 'Frytol-oil-1L-600x600.png', 'Frytol-oil-1L-600x600.png', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-10 14:44:01', NULL),
(69, 10, 31, 5, 'Frytol 2L Cooking Oil 2L Bottle', 'Frytol ', '25.00', '0', 'Frytol Cooking Oil 2L Bottle', '38487_1.jpg', 'frytol-2lt.png', '38487_1.jpg', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-10 14:45:16', NULL),
(70, 11, 33, 5, 'papa jumbo multi-purpose towel 2ply', 'papa', '14.50', '0', 'papa jumbo multi-purpose towel 2ply', '9c0eae98-3ac1-41b6-9211-94bbab9858fc_637013175938736455.jpg', 'papa-jumbo-2ply-multi-purpose-towel.jpg', '9c0eae98-3ac1-41b6-9211-94bbab9858fc_637013175938736455.jpg', '0', 'In Stock', '2020-03-10 14:53:41', NULL),
(71, 8, 35, 5, 'Zwan 6 Big Franks Sausage 560g', 'Zwan', '13.50', '0', 'Zwan 6 Big Franks Sausage 560g', '4135290214b64aba8faac29935dbb92a.jpg', '4135290214b64aba8faac29935dbb92a.jpg', '4135290214b64aba8faac29935dbb92a.jpg', '0', 'In Stock', '2020-03-10 14:55:27', NULL),
(72, 12, 34, 5, 'Snapple Corn Flour', 'Snapple ', '4.20', '0', 'Snapple Corn Flour', 's.jpg', 's.jpg', 's.jpg', '0', 'In Stock', '2020-03-10 15:07:25', NULL),
(73, 11, 33, 5, 'Everpack Jumbo towel', 'Everpack', '8.0', '0', 'Everpack Jumbo towel', 'b6763d699193006cb6bf000c52d28e83.jpg', 'Ever-Jumbo-Towel.png', 'b6763d699193006cb6bf000c52d28e83.jpg', '0', 'In Stock', '2020-03-10 15:08:54', NULL),
(74, 11, 33, 5, 'Shine Jumbo Roll', 'Shine ', '8.00', '0', 'shine jumbo roll', '67519a.jpg', '67519a.jpg', '67519a.jpg', '0', 'In Stock', '2020-03-10 15:10:04', NULL),
(75, 8, 36, 5, 'Mr Perfect Hot Chocolate and Cookies', 'Mr Perfect', '26.00', '0', 'Mr Perfect Hot Chocolate and Cookies', '06859114-BEEC-638A-2EB2094E023C937D-supporting_image_1.png', '__700x700.067F446D-0543-0755-DF50572F2CF4388E-featured_image.png', '06859114-BEEC-638A-2EB2094E023C937D-supporting_image_1.png', '0', 'In Stock', '2020-03-10 15:21:40', NULL),
(76, 8, 45, 5, 'Nescafe 200g', 'Nestle', '32.00', '0', 'Nescafe 200g', 'IMG_0794.JPG', 'IMG_0795.JPG', 'IMG_0794.JPG', '<br /><b>Notice</b>:  Undefined index: shippingCha', 'In Stock', '2020-03-10 15:26:11', NULL),
(77, 8, 37, 5, 'Weetabix 12 Pieces', 'Weetabix ', '15.00', '0', 'Weetabix 12 Pieces\r\nMade with Whole Grain Wheat\r\nGood Source of Fiber', 'snapshotimagehandler_1361599794.jpeg', 'snapshotimagehandler_1361599794.jpeg', 'snapshotimagehandler_1361599794.jpeg', '0', 'In Stock', '2020-03-10 15:29:37', NULL),
(78, 8, 37, 5, 'weetabix 24 pieces', 'Weetabix ', '28.00', '0', 'weetabix 24 pieces', 'snapshotimagehandler_1962443605.jpeg', 'w.jpg', 'snapshotimagehandler_1962443605.jpeg', '0', 'In Stock', '2020-03-10 15:31:58', NULL),
(79, 8, 37, 5, 'weetabix crispy minis Chocolate chip 450g', 'Weetabix ', '17.50', '0', 'weetabix crispy minis Chocolate chip 450g', 'WEETABIX-CRISPY-MINIS-CHOCOLATE-CHIP-450G-5010029222852.jpg', 'new-weetabix-minis-breakfast-cereal-450g-chocolate-1.jpg', '11877fbdd3b1c95ffdb94451b8b0dcc0.jpg', '0', 'In Stock', '2020-03-10 15:34:06', NULL),
(80, 9, 23, 5, 'Svanna Premium Cider Dry  6 bottles', 'Svanna ', '43.50', '0', 'Svanna Premium Cider Dry  6 bottles', 'IMG_1447.JPG', 'IMG_1447.JPG', 'IMG_1447.JPG', '0', 'In Stock', '2020-03-12 00:39:35', NULL),
(81, 10, 32, 5, 'Maggi Shrimp 600g', 'Maggi ', '12.00', '0', 'Maggi Shrimp 600g', 'IMG_1435.JPG', 'IMG_1437.JPG', 'IMG_1436.JPG', '0', 'In Stock', '2020-03-12 00:42:17', NULL),
(82, 9, 24, 5, 'Vitamilk 6 Bottle', 'Vitamilk ', '22.50', '0', 'Vitamilk 6 Bottle', 'IMG_1439.JPG', 'IMG_1440.JPG', 'IMG_1441.JPG', '0', 'In Stock', '2020-03-12 00:47:15', NULL),
(83, 9, 24, 5, 'Namaqua Dry Red Soft and Fruity Red Wine 1L', 'Namaqua ', '14.50', '0', 'Namaqua Dry Red Soft and Fruity Red Wine 1L', 'IMG_1467.JPG', 'IMG_1468.JPG', 'IMG_1469.JPG', '0', 'In Stock', '2020-03-12 01:03:57', NULL),
(84, 9, 24, 5, 'Hhyper Malk 6 Cans 6X330l', 'Hhyper ', '15.00', '0', 'Hhyper Malk 6 Cans 6X330l', 'IMG_1471.JPG', 'IMG_1472.JPG', 'IMG_1471.JPG', '0', 'In Stock', '2020-03-12 01:10:44', NULL),
(85, 9, 38, 5, 'Uncle T Premium Malk 6X33oml 6 bottles', 'Uncle T Premium', '15.00', '0', 'Uncle T Premium Malk 6X33oml 6 bottles', 'IMG_1481.JPG', 'IMG_1482.JPG', 'IMG_1481.JPG', '0', 'In Stock', '2020-03-12 01:16:55', NULL),
(86, 9, 24, 5, 'Cocacola 6 Cans', 'Cocacola ', '17.00', '0', 'Cocacola 6 bottle', 'IMG_1474.JPG', 'IMG_1475.JPG', 'IMG_1474.JPG', '0', 'In Stock', '2020-03-12 01:22:05', NULL),
(87, 9, 24, 5, 'Ceres 100% Sparkling Fruit Juice Blend', 'Ceres', '36.00', '0', 'Ceres 100% Sparkling Fruit Juice Blend', 'IMG_1484.JPG', 'IMG_1485.JPG', 'IMG_1484.JPG', '0', 'In Stock', '2020-03-12 01:24:24', NULL),
(88, 9, 24, 5, 'Alvaro Natural Malk Drink 12 bottle', 'Alvaro ', '28.00', '0', 'Alvaro Natural Malk Drink 12 bottle', 'IMG_1598.JPG', 'IMG_1599.JPG', 'IMG_1598.JPG', '0', 'In Stock', '2020-03-12 01:39:12', NULL),
(89, 9, 38, 5, 'Malt Guinnes 330ml 24 cans', 'Malt Guinnes ', '88.50', '0', 'Malt Guinnes 330ml 24 cans', 'IMG_1601.JPG', 'IMG_1602.JPG', 'IMG_1601.JPG', '0', 'In Stock', '2020-03-12 01:42:07', NULL),
(90, 9, 27, 5, 'Fruit Telli All Nature Juice', 'Fruit Telli ', '48.00', '0', 'Fruit Telli All Nature Juice', 'IMG_1586.JPG', 'IMG_1587.JPG', 'IMG_1588.JPG', '0', 'In Stock', '2020-03-12 02:00:41', NULL),
(91, 9, 24, 5, 'Sun cola 24', 'Sun cola ', '14.00', '0', 'Sun cola 24', 'IMG_1584.JPG', 'IMG_1583.JPG', 'IMG_1584.JPG', '0', 'In Stock', '2020-03-12 02:06:59', NULL),
(92, 13, 40, 5, 'Chapter 2000 Hair Style Product', 'Chapter', '19.50', '0', 'Prevents Breakage & Promotes Hair Growth\r\n\r\nNew Improved With Natural Hair Oils', 'IMG_1751.JPG', 'IMG_1752.JPG', 'IMG_1751.JPG', '0', 'In Stock', '2020-03-15 23:26:25', NULL),
(93, 13, 39, 5, 'Clinic Clear Cocoa Butter Body Lotion 200ml', 'Clinic Clear ', '17.50', '0', 'Clinic Clear Cocoa Butter  Body Lotion 200ml', 'IMG_1711.JPG', 'IMG_1712.JPG', 'IMG_1711.JPG', '0', 'In Stock', '2020-03-15 23:31:38', NULL),
(94, 13, 39, 5, 'Clinic Clear Cocoa Butter Body Lotion 400ml', 'Clinic Clear ', '17.50', '0', 'Clinic Clear Cocoa Butter Body Lotion 400ml', 'IMG_1705.JPG', 'IMG_1707.JPG', 'IMG_1705.JPG', '0', 'In Stock', '2020-03-15 23:40:29', NULL),
(95, 13, 39, 5, 'Clinic Clear Whitening Body Lotion 250ml', 'Clinic Clear ', '11.50', '0', 'Clinic Clear Whitening Body Lotion 250ml', 'IMG_1709.JPG', 'IMG_1710.JPG', 'IMG_1709.JPG', '0', 'In Stock', '2020-03-15 23:48:20', NULL),
(96, 13, 39, 5, 'Clinic Clear Whitening Body Lotion 500ml', 'Clinic Clear ', '20.50', '0', 'Clinic Clear Whitening Body Lotion 500ml', 'IMG_1702.JPG', 'IMG_1703.JPG', 'IMG_1702.JPG', '0', 'In Stock', '2020-03-15 23:53:26', NULL),
(97, 13, 39, 5, 'Cococa Butter Even Sheen Creme', 'Even sheen', '5.20', '0', 'Cococa Butter Even Sheen Creme', 'IMG_1918.JPG', 'IMG_1917.JPG', 'IMG_1918.JPG', '0', 'In Stock', '2020-03-16 00:25:57', NULL),
(98, 13, 39, 5, 'Cocoderm Effet Harmonisant & Clearifiant Harmonizing & Lightening Effect', 'Sivop', '15.60', '0', 'Cocoderm Effet Harmonisant & Clearifiant Harmonizing & Lightening Effect', 'IMG_1792.JPG', 'IMG_1793.JPG', 'IMG_1792.JPG', '0', 'In Stock', '2020-03-16 00:40:51', NULL),
(99, 13, 39, 5, 'Code White 220ml (company dodo cosmetics)', 'Code White', '16.80', '0', 'Code White 220ml (company dodo cosmetics)', 'IMG_1904.JPG', 'IMG_1905.JPG', 'IMG_1906.JPG', '0', 'In Stock', '2020-03-16 00:45:01', NULL),
(100, 13, 39, 5, 'Code White 400ml (company dodo cosmetics)', 'Code White', '33.50', '0', 'Code White 400ml (company dodo cosmetics)', 'IMG_1900.JPG', 'IMG_1901.JPG', 'IMG_1902.JPG', '0', 'In Stock', '2020-03-16 00:48:37', NULL),
(101, 14, 43, 5, 'Cussons Baby talcum Powder', 'Cussons Baby', '10.00', '0', 'Cussons Baby talcum Powder', 'IMG_1863.JPG', 'IMG_1864.JPG', 'IMG_1865.JPG', '0', 'In Stock', '2020-03-16 00:57:58', NULL),
(102, 14, 43, 5, 'Cussons Baby talcum Powder Soft & Smooth', 'Cussons Baby', '10.00', '0', 'Cussons Baby talcum Powder Soft & Smooth', 'IMG_1860.JPG', 'IMG_1861.JPG', 'IMG_1860.JPG', '0', 'In Stock', '2020-03-16 01:33:57', NULL),
(103, 14, 44, 5, ' Jelly Mild & Gentle', 'Cussons Bay', '4.50', '0', 'Cussons Bay Jelly Mild &amp; Gentle', 'IMG_1718.JPG', 'IMG_1719.JPG', 'IMG_1718.JPG', '0', 'In Stock', '2020-03-16 02:15:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategory`, `creationDate`, `updationDate`) VALUES
(16, 8, 'Beverages & Drinks', '2020-03-07 09:27:03', NULL),
(17, 8, ' food & provisions', '2020-03-07 09:30:50', '08-03-2020 08:13:05 AM'),
(18, 8, 'Baby Food', '2020-03-07 09:31:18', NULL),
(19, 8, 'world food', '2020-03-08 01:21:46', NULL),
(20, 9, ' Tea, Coffee & Cocoa', '2020-03-08 01:24:53', NULL),
(21, 8, 'CONFECTIONERY', '2020-03-09 00:16:09', NULL),
(22, 8, 'Biscuits', '2020-03-09 04:10:37', NULL),
(23, 9, ' Alcoholic  Drinks', '2020-03-09 19:41:33', '03-04-2020 08:48:40 PM'),
(24, 9, 'Soft Drinks', '2020-03-09 19:44:24', '03-04-2020 08:48:53 PM'),
(26, 9, ' Communion', '2020-03-09 20:09:50', NULL),
(27, 9, 'fruit juice', '2020-03-09 20:46:00', NULL),
(29, 9, 'Non Alcoholic', '2020-03-10 10:03:25', NULL),
(30, 9, 'Non Alcoholic', '2020-03-10 14:23:08', NULL),
(31, 10, 'oil', '2020-03-10 14:28:43', NULL),
(32, 10, 'Spices ', '2020-03-10 14:29:23', NULL),
(33, 11, 'Kitchen Supplies', '2020-03-10 14:50:45', NULL),
(34, 12, 'HOME BAKING', '2020-03-10 15:05:40', NULL),
(35, 8, 'Ready To Eat & Cook', '2020-03-10 15:11:59', NULL),
(36, 8, 'Cookies', '2020-03-10 15:19:52', NULL),
(37, 8, 'Breakfast Foods', '2020-03-10 15:27:40', NULL),
(38, 9, 'Malk', '2020-03-12 01:15:14', NULL),
(39, 13, 'Skin Care', '2020-03-15 23:12:34', NULL),
(40, 13, 'Hair Care', '2020-03-15 23:13:15', NULL),
(41, 13, 'Oral Care', '2020-03-15 23:13:31', NULL),
(42, 9, 'Milk', '2020-03-16 00:05:35', NULL),
(43, 14, 'Powder', '2020-03-16 02:10:30', NULL),
(44, 14, 'Baby Pomade', '2020-03-16 02:11:34', NULL),
(45, 8, 'Beverages', '2020-04-03 13:36:58', NULL),
(46, 15, 'Soft', '2020-04-03 14:55:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `total`
--

CREATE TABLE `total` (
  `id` int(11) NOT NULL,
  `userId` varchar(50) NOT NULL,
  `track` varchar(50) NOT NULL,
  `subamt` varchar(50) NOT NULL,
  `delivery` varchar(50) NOT NULL,
  `total` double NOT NULL,
  `Status` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `total`
--

INSERT INTO `total` (`id`, `userId`, `track`, `subamt`, `delivery`, `total`, `Status`, `date`) VALUES
(25, '7', 'SGM-590418', '109.5.00', '5.475', 114.975, 0, '2020-04-15 16:37:03'),
(26, '7', 'SGM-421684', '109.5.00', '5.475', 114.975, 0, '2020-04-15 16:37:07'),
(27, '7', 'SGM-19883', '268.00', '5.36', 273.36, 0, '2020-04-15 16:42:51'),
(28, '7', 'SGM-103236', '106.00', '5.3', 111.3, 0, '2020-04-15 16:51:19'),
(29, '7', 'SGM-687476', '32.00', '4.8', 36.8, 0, '2020-04-15 16:53:06'),
(30, '7', 'SGM-442150', '59.00', '5.9', 64.9, 0, '2020-04-16 09:57:57'),
(31, '7', 'SGM-436960', '132.5.00', '6.625', 139.125, 0, '2020-04-16 10:03:32'),
(32, '7', 'SGM-659542', '221.00', '6.63', 227.63, 0, '2020-04-16 10:06:28'),
(33, '7', 'SGM-324963', '50.00', '5', 55, 0, '2020-04-16 10:07:02'),
(34, '7', 'SGM-509009', '60.2', '6.02', 66.22, 0, '2020-04-16 11:16:19');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userEmail`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 11:18:50', '', 1),
(2, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 11:29:33', '', 1),
(3, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 11:30:11', '', 1),
(4, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 15:00:23', '26-02-2017 11:12:06 PM', 1),
(5, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:08:58', '', 0),
(6, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:09:41', '', 0),
(7, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:10:04', '', 0),
(8, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:10:31', '', 0),
(9, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:13:43', '', 1),
(10, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-27 18:52:58', '', 0),
(11, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-27 18:53:07', '', 1),
(12, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-03 18:00:09', '', 0),
(13, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-03 18:00:15', '', 1),
(14, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-06 18:10:26', '', 1),
(15, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-07 12:28:16', '', 1),
(16, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-07 18:43:27', '', 1),
(17, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-07 18:55:33', '', 1),
(18, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-07 19:44:29', '', 1),
(19, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-08 19:21:15', '', 1),
(20, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-15 17:19:38', '', 1),
(21, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-15 17:20:36', '15-03-2017 10:50:39 PM', 1),
(22, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-16 01:13:57', '', 1),
(23, 'hgfhgf@gmass.com', 0x3a3a3100000000000000000000000000, '2018-04-29 09:30:40', '', 1),
(24, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2019-08-20 13:12:40', NULL, 0),
(25, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2019-08-20 13:14:59', NULL, 1),
(26, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2019-08-23 22:51:54', NULL, 1),
(27, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2019-08-23 22:55:56', NULL, 1),
(28, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2019-08-24 15:51:17', NULL, 1),
(29, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2019-08-26 07:35:11', NULL, 1),
(30, 'ee@ee.com', 0x3a3a3100000000000000000000000000, '2019-10-11 09:35:50', NULL, 0),
(31, 'aa@aa.com', 0x3a3a3100000000000000000000000000, '2019-10-11 09:35:57', NULL, 0),
(32, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2019-10-11 09:36:25', NULL, 1),
(33, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2019-10-11 10:05:34', NULL, 1),
(34, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-09 14:57:52', NULL, 1),
(35, 'hh@hh.com', 0x3a3a3100000000000000000000000000, '2020-01-12 03:07:31', NULL, 0),
(36, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-12 03:07:41', NULL, 1),
(37, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-12 04:50:50', NULL, 1),
(38, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-12 05:43:15', NULL, 1),
(39, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-13 05:08:56', NULL, 0),
(40, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-13 05:09:17', NULL, 1),
(41, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-16 22:51:20', NULL, 1),
(42, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-28 01:59:58', NULL, 1),
(43, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-01-30 21:36:00', NULL, 1),
(44, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-02-06 00:09:45', NULL, 1),
(45, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-02-06 00:56:10', NULL, 1),
(46, 'ss@ss.com', 0x3a3a3100000000000000000000000000, '2020-02-06 01:35:40', NULL, 1),
(47, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-02-09 14:40:41', NULL, 1),
(48, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-02-11 15:22:37', NULL, 1),
(49, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-02-11 16:41:29', NULL, 1),
(50, 'bb@bb.com', 0x3135342e3136302e31302e3330000000, '2020-02-25 21:20:20', NULL, 1),
(51, 'bb@bb.com', 0x3135342e3136302e362e313531000000, '2020-03-10 19:12:29', NULL, 1),
(52, 'bb@bb.com', 0x3135342e3136302e362e313531000000, '2020-03-10 19:12:30', NULL, 1),
(53, 'razki99@gmail.com', 0x3135342e3136302e312e313831000000, '2020-03-17 17:19:22', NULL, 1),
(54, 'razki99@gmail.com', 0x3135342e3136302e312e313831000000, '2020-03-17 17:19:24', NULL, 1),
(55, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-04-04 18:48:07', NULL, 1),
(56, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-04-15 04:02:50', NULL, 1),
(57, 'bb@bb.com', 0x3a3a3100000000000000000000000000, '2020-04-15 09:58:06', NULL, 1),
(58, 'razki@razki.com', 0x3a3a3100000000000000000000000000, '2020-04-15 11:42:22', NULL, 0),
(59, 'razki99@gmail.com', 0x3a3a3100000000000000000000000000, '2020-04-15 11:42:35', NULL, 1),
(60, 'razki99@gmail.com', 0x3a3a3100000000000000000000000000, '2020-04-15 11:53:19', NULL, 1),
(61, 'razki99@gmail.com', 0x3a3a3100000000000000000000000000, '2020-04-15 15:46:22', NULL, 1),
(62, 'sconzypee@gmail.com', 0x33312e32302e31302e31303400000000, '2020-09-27 06:45:39', NULL, 1),
(63, 'admin@admin.com', 0x3130352e3130332e31362e3233310000, '2020-10-06 08:11:23', NULL, 0),
(64, 'admin@admin.com', 0x3130352e3130332e31362e3233310000, '2020-10-06 08:11:23', NULL, 0),
(65, 'aa@aa.com', 0x34312e3133392e31322e313639000000, '2020-11-29 19:51:51', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `contactno1` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `shippingAddress` longtext,
  `shippingState` varchar(255) DEFAULT NULL,
  `shippingCity` varchar(255) DEFAULT NULL,
  `shippingPincode` int(11) DEFAULT NULL,
  `billingAddress` longtext,
  `billingState` varchar(255) DEFAULT NULL,
  `billingCity` varchar(255) DEFAULT NULL,
  `billingPincode` int(11) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `contactno`, `contactno1`, `password`, `shippingAddress`, `shippingState`, `shippingCity`, `shippingPincode`, `billingAddress`, `billingState`, `billingCity`, `billingPincode`, `regDate`, `updationDate`) VALUES
(1, 'Anuj Kumar', 'anuj.lpu1@gmail.com', 9009857868, '', 'f925916e2754e5e03f75dd58a5733251', 'CS New Delhi', 'New Delhi', 'Delhi', 110001, 'New Delhi', 'New Delhi', 'Delhi', 110092, '2017-02-04 19:30:50', ''),
(2, 'Amit ', 'amit@gmail.com', 8285703355, '', '5c428d8875d2948607f3e3fe134d71b4', '', '', '', 0, '', '', '', 0, '2017-03-15 17:21:22', ''),
(3, 'hg', 'hgfhgf@gmass.com', 1121312312, '', '827ccb0eea8a706c4c34a16891f84e7b', '', '', '', 0, '', '', '', 0, '2018-04-29 09:30:32', ''),
(4, 'Michael Kay', 'bb@bb.com', 246789654, '0246789654', '21ad0bd836b90d08f4cf640b4c298e7c', 'Poly', NULL, 'Ho', NULL, NULL, NULL, NULL, NULL, '2019-08-20 13:14:56', NULL),
(5, 'sad', 'ss@ss.com', 90989, '98989', '3691308f2a4c2f6983f2880d32e29c84', 'sdkfj', NULL, 'kjl', NULL, NULL, NULL, NULL, NULL, '2020-02-06 01:35:25', NULL),
(6, 'David Razki', 'razki99@gmail.com', 248766278, '0248766278', '827ccb0eea8a706c4c34a16891f84e7b', 'Bankoe', NULL, 'Ho', NULL, NULL, NULL, NULL, NULL, '2020-03-17 17:19:11', NULL),
(7, 'david razki', 'razki99@gmail.com', 248766278, '0248766278', '4124bc0a9335c27f086f24ba207a4912', 'bankoe', NULL, 'Ho', NULL, NULL, NULL, NULL, NULL, '2020-04-15 11:42:13', NULL),
(8, 'Kobee Odartey', 'sconzypee@gmail.com', 0, '+233244877803', '40feef401a5968afc5f5b8ad67da42fd', 'Oranjeboomstraat', NULL, 'Rotterdam', NULL, NULL, NULL, NULL, NULL, '2020-09-27 06:45:14', NULL),
(9, 'you', 'aa@aa.com', 808, '879898', '4124bc0a9335c27f086f24ba207a4912', 'kdj', NULL, 'jfk', NULL, NULL, NULL, NULL, NULL, '2020-11-29 19:51:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `userId`, `productId`, `postingDate`) VALUES
(1, 1, 0, '2017-02-27 18:53:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliverycode`
--
ALTER TABLE `deliverycode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productreviews`
--
ALTER TABLE `productreviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `total`
--
ALTER TABLE `total`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deliverycode`
--
ALTER TABLE `deliverycode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `productreviews`
--
ALTER TABLE `productreviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `total`
--
ALTER TABLE `total`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
