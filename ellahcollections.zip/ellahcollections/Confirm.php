<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
{   
header('location:login.php');
}
else{
if (isset($_POST['submit'])) {

$tracking_i =rand(100,7899);
$tracking_id ="Ell-".$tracking_i;
$_SESSION['track']=$tracking_id;


$quantity=$_SESSION['quantity'];
$pdd=$_SESSION['pid'];
$value=array_combine($pdd,$quantity);
foreach($value as $qty=> $val34){
mysqli_query($con,"insert into orders(
tracking_id,userId,productId,quantity,shippingCharge ) values('$tracking_id','".$_SESSION['id']."','$qty','$val34','".$_SESSION['Delivery']."')");








$to  =$_SESSION['login'];
// subject
$subject ="Dornu";

// message
$message="Your Order ID Is ".$_SESSION['track']." <br>".$_SESSION['EMAIL'];

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

//Additional headers

$headers .= 'From:Dornu <dornu@dornu.com>' . "\r\n";

// Mail it
mail($to, $subject, $message, $headers);
//echo"<font color='green'>Your Request Has been Received. We will Get Back to you soon</font>";

}
mysqli_query($con,"INSERT INTO total (
userId,	track,subamt,delivery,total ) values('".$_SESSION['id']."','$tracking_id','". $_SESSION['sub']."','".$_SESSION['Delivery']."','". $_SESSION['totalprice']."')");


unset($_SESSION['cart']);
header('location:finish.php');

}
}
?>

<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php'); ?>

<body>
<!-- HEADER -->
<header>
<!-- top Header -->
<?php  include('includes/top-header.php'); ?>
<!-- /top Header -->

<!-- header -->
<?php  include('includes/main-header.php'); ?>

<!-- container -->
</header>
<!-- /HEADER -->

<!-- NAVIGATION -->
<?php include 'includes/main-nav.php'; ?>
<!-- /NAVIGATION -->

<!-- BREADCRUMB -->
<div id="breadcrumb">
<div class="container">
<ul class="breadcrumb">
<li><a href="index.php">Home</a></li>
<li class="active">Details</li>
</ul>
</div>
</div>
<!-- /BREADCRUMB -->

<!-- section -->
<div class="section">
<!-- container -->
<div class="container">
<!-- row -->
<div class="row">
<!--<form id="checkout-form" class="clearfix">-->
<div class="col-md-6">
<div class="billing-details">


<div class="section-title">
<?php 
if($_SESSION['edit']){
echo "<span style='color:green;'>".$_SESSION['edit']."</span><br>";
}
$_SESSION['edit']=null;
?>
<h3 class="title">CHECKOUT</h3>
</div>


<div class="input-checkbox">

<label for="shipping-1">1. ADDRESS DETAILS</label>
<div clas="caption">
<p><?php $qry=mysqli_query($con,"select * from users where id='".$_SESSION['id']."'");
while ($rt=mysqli_fetch_array($qry)) {
echo "<b>".htmlentities($rt['name'])."</b><br />";
echo htmlentities($rt['shippingAddress'])."<br />";
echo htmlentities($rt['shippingCity'])."<br />";
echo htmlentities($rt['contactno'])."<br />";
echo htmlentities($rt['contactno1']);
}

?> <br><span><a href="my-account.php" style="font-size: 20px; color: #e80505;">EDIT</a></span>
</p>
</div>
</div>



<div class="input-checkbox">

<label for="shipping-1">2. PAYMENT METHOD</label>
<div clas="caption">
<p>

<ol>
	<li>Send to local account</li>
	<li>Account Numner: 237957998</li>
	<li>Bank Name: GT Bank</li>
	<li>Account Name: Ellah Collections</li>
	<li>Enter Order ID eg"DN6634"</li>
	<li>Send payment recipt to whatsapp number : 08033280598"</li>
</ol>
</p>
</div>
</div>


<div class="input-checkbox">

<hr><br>
<div clas="caption">
<p><span style="font-size: 17px;">Subtotal<span style="float: right;"><?php echo "N ". $_SESSION['sub']; ?></span></span><br><br>
<span style="font-size: 17px;"> Delivery Charge<span style="float: right;"><?php echo "N ". $_SESSION['Delivery']; ?></span></span><br> <hr>
<span> <b style="font-size: 20px;">Total</b><span style="float: right; color: #e80505;"><?php echo "N ". $_SESSION['totalprice']; ?></span></span>


<!--<br><span><a href="my-account.php" style="font-size: 20px; color: #e80505;">CHANGE</a></span>-->
</p>
</div>
</div>



<div class="pull-right">
<form name="payment" method="post">
<input type="submit" value="Confirm" name="submit" class="primary-btn">
</form>							</div>
<!--<a href="finish.php"> <span style="background-color: #e80505;  font-size: 20px; color: white; width: 100%; ">Confirm</span></a>-->	


</div>
</div>

<div class="col-md-6">
<div class="shiping-methods">

</div>
<form name="cart" method="post" action="checkout.php">	
<?php
if(!empty($_SESSION['cart'])){
?>
<div class="col-md-12">
<div class="order-summary clearfix">
<div class="section-title">
<h3 class="title">YOUR ORDER</h3>
</div>
<table class="shopping-cart-table table">
<!--<thead>
<tr>
<th clas="text-center">	</th>
<th clas="text-center"></th>

</tr>
</thead>-->
<tbody>
<?php
$pdtid=array();
$sql = "SELECT * FROM products WHERE id IN(";
foreach($_SESSION['cart'] as $id => $value){
$sql .=$id. ",";
}
$sql=substr($sql,0,-1) . ") ORDER BY id ASC";
$query = mysqli_query($con,$sql);
$totalprice=0;
$totalqunty=0;
$subtotaL=0;
//$shippingCharge=0;
if(!empty($query)){
while($row = mysqli_fetch_array($query)){
$quantity=$_SESSION['cart'][$row['id']]['quantity'];

$subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productPrice'];
$subtota= $_SESSION['cart'][$row['id']]['quantity']*$row['productPrice'];
//$shippingChargeL= $row['shippingCharge'];
$totalprice += $subtotal;
$subtotaL += $subtota;
//$shippingCharge +=$shippingChargeL;
$_SESSION['qnty']=$totalqunty+=$quantity;

array_push($pdtid,$row['id']);
//print_r($_SESSION['pid'])=$pdtid;exit;
echo $msg="

<tr>


<td class='thumb'><img src='admin/productimages/".$row['id']."/". $row['productImage1']."' alt='' width='124' height='146' ></td>
<td class='details'>
<h4 class='details'><a href='product-page.php?pid=".htmlentities($pd=$row['id'])."'>".$row['productName']. "<br><br> <span style='color:#000;'>Qty: ". $_SESSION['cart'][$row['id']]['quantity']. "<br><br> <span style='color:#e80505;'>N " .$subtota;
$_SESSION['sid']=$pd;
"</a></h4></td><br>
 ";} }
$_SESSION['pid']=$pdtid;
$_SESSION['EMAIL']=$msg;
?>				</tr>
</tbody>
<!--<tfoot>

</tr>
</tfoot>-->
</table>
<div class="pull-right">
<a href="my-cart.php" class="primary-btn">MODIFY CART</a><br><br>
</div>
</div>

</div>


</form>


<br>



<?php } else {
echo "Your shopping Cart is empty";
}?>
</div>

<!-- /row -->
</div>
<!-- /container -->
</div>
<!-- /section -->

<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>
<!-- /FOOTER -->

<!-- jQuery Plugins -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/nouislider.min.js"></script>
<script src="js/jquery.zoom.min.js"></script>
<script src="js/main.js"></script>

</body>

</html>
