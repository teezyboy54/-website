<?php 
session_start();
error_reporting(0);
$productIdd=$_GET['po'];
$poId=$_GET['poId'];
//echo $productIdd;
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8"><?php 

include('includes/config.php');
//$_SESSION['order']=null;


?>

<!DOCTYPE html>
<html lang="en">
<?php if(isset($_POST['Confirm'])){
$confirm = $_POST['confirm'];

$productId = $_POST['productId'];

$query=mysqli_query($con,"INSERT into ordertrackhistory(orderId,status,productId) values('$tracking_id','Delivered','$productId')");
$sql=mysqli_query($con,"UPDATE orders set orderStatus='Delivered' where productId='$productId'");
}?>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Shop Orders</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css" />
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<?php  include('includes/top-header.php'); ?>
		<!-- /top Header -->

		<!-- header -->
		<?php  include('includes/main-header.php'); ?>
		
		<!-- container -->
	</header>
	<!-- /HEADER -->

	

	<!-- NAVIGATION -->
	<?php include 'includes/main-nav.php'; ?>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="index.php">Home</a></li>
				<li class="active">Orders Details</li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
					<div class="col-md-8">
						<div class="shiping-methods">
							<div class="section-title">
								<h4 class="title">Orders Details</h4>
							</div>
							<div clas="input-checkbox">
								
								<label for="shipping-1" id="shipping-1"></label>

								<div class="caption">
									
									


<?php /*if(isset($_POST['LTrack'])){ 
    
    	$Track =$_POST['Track'];
   	
$ret = mysqli_query($con,"SELECT * FROM ordertrackhistory WHERE where orders.orderStatus is null order");
 */

/*$ret=mysqli_query($con,"SELECT products.productImage1,products.id 
as ppid,products.productName 
as productname,orders.shippingCharge
as shippingcharge,orders.quantity 
as quantity,orders.orderDate 
as orderdate,orders.productId,products.productPrice 
as productprice,orders.id 
as id ,orders.tracking_id 
as trackingid,orders.orderStatus  as ordSt
from orders 
join ordertrackhistory
on ordertrackhistory.productId=orders.productId
join products 
on products.id=orders.productId  where ordertrackhistory.productId='$productIdd' order by orders.orderDate  desc ");
*/
/*$ret=mysqli_query($con,"SELECT products.productImage1,products.id 
as ppid,products.productName 
as productname,orders.shippingCharge
as shippingcharge,orders.quantity 
as quantity,orders.orderDate 
as orderdate,orders.productId,products.productPrice 
as productprice,orders.id 
as id ,orders.tracking_id 
as trackingid,orders.orderStatus  as ordSt
from orders 
join ordertrackhistory
on ordertrackhistory.productId=orders.productId
join products 
on products.id=orders.productId  where orders.productId='$productIdd' order by orders.orderDate  desc ");

*/


$ret=mysqli_query($con,"SELECT products.productImage1,products.id 
as ppid,products.productName 
as productname,orders.shippingCharge
as shippingcharge,orders.quantity 
as quantity,orders.orderDate 
as orderdate,products.productPrice 
as productprice,orders.orderStatus,orders.id 
as id ,orders.tracking_id 
as trackingid,orders.productId from orders 
join products 
on products.id=orders.productId where  orders.productId='$productIdd' order by orderDate desc");


$num=mysqli_num_rows($ret);  
if($num>0)  
{?>
	<a href="orders.php" style="font-size: 23px;" >Back</a>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="datatable-1 table table-bordered table-striped	 display table-responsive">
<thead>
										<tr>
											<th>#</th>
											<th>Order ID</th>
											<th> Image</th>
											<th> Product Name</th>
											<th>Quantity</th>
											<th>Status</th>
											<th width="50">Unit Price</th>
											<th>Grand Total </th>
											<th>Confirm Received </th>
											
										
										</tr>
									</thead>

	<?php 
	$con=1;
	$Grand=0;
if($row=mysqli_fetch_array($ret))
      { //echo $row['orderStatus']. "kjfkdj";
     ?>
		
    
    
      <tr height="20" >
      <td  class="fontkink"><?php echo $con; ?></td>
      <td  class="fontkink"><?php echo htmlentities($row['trackingid']);?></td>
      <td  class="fontkink"><img style="width: 40px; height:80px;"src="admin/productimages/<?php echo htmlentities($row['ppid']);?>/<?php echo htmlentities($row['productImage1']);?>" data-echo="admin/productimages/<?php echo htmlentities($row['ppid']);?>/<?php echo htmlentities($row['productImage1']);?>" alt=""/></td>
      <td  class="fontkink"><?php echo htmlentities($row['productname']);?></td>
      <td  class="fontkink" widh="10" heght="10" stle="color: #e80505"><?php echo htmlentities($row['quantity']);?></td>
      <td  class="fontkink" widh="10" heght="10" stle="color: #e80505"><?php if ($row['orderStatus']==null){echo "You Will Receive Update Soon:"; }else{echo htmlentities($row['orderStatus']);}?></td>
      <?php $GrandTotal =htmlentities($row['quantity']*$row['productprice']);
      $Grand+=$GrandTotal;
      ?>
      <td  class="fontkink" with="90" stle="color: #e80505"><?php echo "N".htmlentities($row['productprice'])?></td>
      <td  class="fontkink" with="90" stle="color: #e80505"><b><?php echo "N". $GrandTotal;?></b></td>
      <td  class="fontkink" with="90" stle="color: #e80505"><b><?php if($row['orderStatus']=="Out For Delivery" ){?>
		 <form method="post" action="" > 
		<input  type="text" hidden name="confirm" value="<?php echo $row['trackingid']?>">
		<input  type="text" hidden name="productId" value="<?php echo $row['productId']?>">
	  <input class="btn primary" type="submit" name="Confirm" value="Confirm"></form></b></td>
		
   <?php }$con+=1;} 

?>
<tr>
	<th colspan="6"><b>Total</b></th>
	<th colspan="4" style="font-size: 13px;color: #e80505"><b><?php echo "N". $Grand; ?></b></th>
</tr>
</tr>
</table>
<?php }else{
   ?>
   <tr ><a href="orders.php" style="font-size: 23px;" >Back</a><br>
   <td colspan="2" ><span style="color: red;">You Will Receive Update Soon: </span></td>
   </tr>
   <?php } ?>
</div></div>
</div></div>
<!-- /row -->
</div></div>
<!-- /container -->
<!-- /section -->	
<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>
<!-- /FOOTER -->


	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

<