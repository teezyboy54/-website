<?php 
session_start();
error_reporting(0);
include('includes/config.php');
$_SESSION['order']=null;

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Shop Orders</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css" />
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<?php  include('includes/top-header.php'); ?>
		<!-- /top Header -->

		<!-- header -->
		<?php  include('includes/main-header.php'); ?>
		
		<!-- container -->
	</header>
	<!-- /HEADER -->

	

	<!-- NAVIGATION -->
	<?php include 'includes/main-nav.php'; ?>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="index.php">Home</a></li>
				<li class="active">Orders</li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
					<div class="col-md-8">
						<div class="shiping-methods">
							<div class="section-title">
								<h4 class="title">Orders</h4>
							</div>
							<div clas="input-checkbox">
								
								<label for="shipping-1" id="shipping-1"></label>

								<div class="caption">
									
									


<?php /*if(isset($_POST['LTrack'])){ 
    
    	$Track =$_POST['Track']; orders
   */ 
//$outerQuery=mysqli_query($con,"SELECT * from total where Status =0 and userId='".$_SESSION['id']."' order by id desc");
echo  $_SESSION['email'];
$outerQuery=mysqli_query($con,"SELECT * from orders where userId='".$_SESSION['id']."' order by id desc");
$con=1;
$num=mysqli_num_rows($outerQuery);
if($num>0)
{

?>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="datatable-1 table table-bordered table-striped	 display table-responsive">
<thead>
										<tr>
											<th>#</th>
											<th> Order ID</th>
											<th> Date</th>
											<th> Details</th>
											
										
										</tr>
									</thead>

   
    <?php while($row=mysqli_fetch_array($outerQuery))
{
	

 ?>
      <tr height="20" >
      <td  class="fontkink"><?php echo $con; ?></td>
      <td  class="fontkink"><?php echo htmlentities($row['tracking_id']);?></td>
      <td  class="fontkink"><?php echo htmlentities($row['orderDate']);?></td>
      
      <td  class="fontkink" with="90" stle="color: #e80505"><b><a href="order.php?po=<?php echo $row['productId'];  ?>&&?poId=<?php echo $row['id'];  ?>">View</a></b></td>
      </tr>

   <?php $con+=1; }

?>


</table>
<?php }else{
   ?>
   <tr >
   <td colspan="2" ><span style="color: red;">There Is No New Order</span></td>
   </tr>
   <?php  }?>
</div></div>
</div></div>
<!-- /row -->
</div></div>
<!-- /container -->
<!-- /section -->	
<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>
<!-- /FOOTER -->


	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
