<!-- NAVIGATION -->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			<div id="responsive-nav">
				<!-- category nav -->
				<div class="category-nav show-on-click">
					<?php
					$_SESSION['cid']=$cid;
					$sql=mysqli_query($con,"SELECT *  from category where id='$cid'  ");

								if($row=mysqli_fetch_array($sql))
								{
								   ?> 
					<span class="category-header">
						<?php echo $row['categoryName']; }?> <i class="fa fa-list"></i></span>
				
					<ul class="category-list">
						<?php 
						
									
								   $sqll=mysqli_query($con,"SELECT *  from subcategory where categoryid='$cid'  ");
								   while($roww=mysqli_fetch_array($sqll))
											{
								    ?>
						<li class="dropdown side-dropdown">

							<a href="subcategory-products.php?sid=<?php echo $roww['id']; ?>">
								<?php echo $roww['subcategory'];?> <i clss="fa fa-angle-right"></i></a>
							<?php } ?>
							<!--<div class="custom-menu">
								<div class="row">
									<div class="col-md-4">
										<ul class="list-links">
											<h3 class="list-links-title"><?php //echo $roww['subcategory']; }?></h3></li>
											
										</ul>
										<hr class="hidden-md hidden-lg">
									</div>
									
								</div>
								
							</div>-->
						</li>
						
					</ul>
				</div>
				<!-- /category nav -->

				<!-- menu nav --
				<div class="menu-nav">
					<span class="menu-header">Menu <i class="fa fa-bars"></i></span>
					<ul class="menu-list">
						<li><a href="index.php">Home</a></li>
						<li><a href="#">Sell With Us</a></li>
							
					</ul>
				</div>
				<!-- menu nav -->
			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->