<div class="side-menu animate-dropdown outer-bottom-xs">
    <div class="head"><i class="icon fa fa-align-justify fa-fw"></i> Regions</div>        
    <nav class="yamm megamenu-horizontal" role="navigation">
  
        <ul class="nav">
            <li class="dropdown menu-item">
              <?php $sql=mysqli_query($con,"select id,region  from region");
while($row=mysqli_fetch_array($sql))
{
    ?>
                <a href="Region.php?regn=<?php echo $row['region'];?>" class="dropdown-toggle"><i class="icon fa fa-desktop fa-fw"></i>
                <?php echo $row['region'];?></a>
                <?php }?>
                        
</li>
</ul>
    </nav>
</div>