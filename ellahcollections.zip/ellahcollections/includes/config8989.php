

<?php
/*
$db['db_host'] = 'sql207.epizy.com';
$db['db_user'] = 'epiz_22725917';
$db['db_pass'] = 'TjI0VWUBXIp';
$db['db_name'] = 'epiz_22725917_rental';
*/
//$con = mysqli_connect ("localhost", "mansaqkw_root", "Aa123456789@", "mansaqkw_dornu");
$con = mysqli_connect ("localhost", "root", "", "dornu");

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
} 

/*
$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

if(!$connection){ die(mysqli_error($connection)); }

*/


?>