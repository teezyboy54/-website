<?php 
session_start();
error_reporting(0);
if(!empty($_SESSION['cart'])){
foreach($_POST['quantity'] as $key => $val){
if($val==0){
unset($_SESSION['cart'][$key]);
}else{
$_SESSION['cart'][$key]['quantity']=$val;

}

}
$_SESSION['edit']="Your Cart Has Been Updated";
header('location: ../my-cart.php');
//echo "<script>alert('Your Cart hasbeen Updated');</script>";
}



 ?>