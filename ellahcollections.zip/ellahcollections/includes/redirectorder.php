<?php 

header("location: ../orders.php");
 ?>