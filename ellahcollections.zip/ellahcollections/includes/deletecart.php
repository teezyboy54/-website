<?php 

session_start();
// Code for Remove a Product from Cart
if(isset($_POST['remove_code']))
{

if(!empty($_SESSION['cart'])){
foreach($_POST['remove_code'] as $key){

unset($_SESSION['cart'][$key]);
}
$_SESSION['remove']="Your Cart Has Been Updated";
header('location: ../my-cart.php');

//echo "<script>alert('Your Cart has been Updated');</script>";
}
} ?>