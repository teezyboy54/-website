<div id="header">
<div class="container">
<div class="row">

<div class="col-sm-2"><div class="header-logo" style="margin-top: 9px;">
<a class="logo" href="index.php">
<img src="./img/ellas.jpg" alt="">
</a>
</div>
</div>

<div class="col-sm-7">
<form method="post" action="search-result.php">
<div class="input-group" style="margin-top: 24px;">

     <!-- <input required type="text" class="form-control" name="product" placeholder="Enter Product Name" style="height: 38px;">
      <button class="search-btn" type="submit" name="search"><i class="fa fa-search"></i></button>   
    </div>--->
     <input required type="text" class="form-control" list="search" id="search" name="product" placeholder="Enter Product Name" style="height: 38px;">
    <div class="input-group-btn">
      <button class="btn btn-default" type="submit" style="height: 38px;">
        <i class="fa fa-search"></i>
      </button>
    </div></div>
</form>
</div>

<datalist id="search">
<?php 
$query=mysqli_query($con,"SELECT * FROM products");
while($row=mysqli_fetch_array($query)){

$option = $row['productName'];
?>
<option> <?php echo $option; ?></option>
<?php } ?>
</datalist>

<div class="col-sm-3" class="pull-right" ><ul class="header-btns">
	<!-- Cart -->
						
						<!-- /Cart --> 
						<!-- Account -->
						<li class="header-account dropdown default-dropdown">
						<a href="#">	<div class="dropdown-toggle" role="button" data-toggl="dropdown" aria-expanded="true">
								<div class="header-btns-icon">
									<i class="fa fa-user-o"></i>
								</div>
								<?php if(strlen($_SESSION['login']))
										{   
										echo "<a href='logout.php'><strong class='text-uppercase'>Logout<i clas='fa fa-caret-down'></i></strong></a>";
										}
										else{
											echo "<a href='login.php'><strong class='text-uppercase'>Login<i clas='fa fa-caret-down'></i></strong></a>";
										//echo "<strong class="text-uppercase">Login<i clas="fa fa-caret-down"></i></strong>"	;
										}?>
								<!--<strong class="text-uppercase">Login<i clas="fa fa-caret-down"></i></strong>-->
							</div></a>
							 <!--<strong class="text-uppercase"><a href="login.php" class="text-uppercase">Login Not</a></strong>-->
							<ul class="custom-menu">
								<li><a href="my-account.php"><i class="fa fa-user-o"></i> My Account</a></li>
								<!--<li><a href="#"><i class="fa fa-heart-o"></i> My Wishlist</a></li>
								<li><a href="#"><i class="fa fa-exchange"></i> Compare</a></li>
								<li><a href="#"><i class="fa fa-check"></i> Checkout</a></li>-->
								<li><a href="login.php"><i class="fa fa-unlock-alt"></i> Login</a></li>
								<li><a href="login.php"><i class="fa fa-user-plus"></i><!-- Create An Account--></a></li>
							</ul>
						</li>
						<!-- /Account -->

						

<?php include('menu-bar.php');?>



						<!-- Mobile nav toggle-->
						<li class="nav-toggle">
							<button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
						</li>
						<!-- / Mobile nav toggle -->
					</ul>
				</div></div>
</div>
</div>

