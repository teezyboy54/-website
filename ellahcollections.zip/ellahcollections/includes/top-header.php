<div id="top-header" style="background: black">
			<div class="container" >
				<div class="pull-left">
				
				<center>
					<span style="color: white; font-size: 25px;"> <b>CALL TO ORDER<span style="color: #ff7676; font-size: 25px;"> 09000009000</b></span></span>
				
				</center>
				
				</div>



				<div class="pull-right">
						
					<a href="newbrand.php"><button class="primary-btn add-to-cart">New Brands</button></a>
					
				</div>
			</div>
		</div>