<!-- NAVIGATION -->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			<div id="responsive-nav">
				<!-- category nav -->
				<div class="category-nav show-on-click">
					<span class="category-header">Categories <i class="fa fa-list"></i></span>
					<ul class="category-list">
						<?php 
						
						$sql=mysqli_query($con,"SELECT *  from category  ");

								while($row=mysqli_fetch_array($sql))
								{
									$id=$row['id'];
								   $sqll=mysqli_query($con,"SELECT *  from subcategory where categoryid=' $id'  ");
								    ?>
						<li class="dropdown side-dropdown">

							<a class="dropdown-toggle" data-tggle="dropdown" aria-expanded="true" href="products.php?cid=<?php echo $row['id'];?>"><?php echo $row['categoryName'];?> <i clas="fa fa-angle-right"></i></a>
							<div class="custom-menu">
								<div class="row">
									<div class="col-md-4">
										<ul class="list-links">
											<h3 class="list-links-title"><?php echo $row['categoryName']; ?></h3></li>
											<?php 
											/*while($roww=mysqli_fetch_array($sqll))
											{
								   				 ?>
											<li>
												
											<li><a href="products.php?cid=<?php echo $row['id'];?>&sid=<?php echo $roww['id']; ?>"><?php echo $roww['subcategory'];?></a></li>
										<?php } */?>
										</ul>
										<hr class="hidden-md hidden-lg">
									</div>
									
								</div>
								
							</div>
						</li><?php } ?>
						
					</ul>
				</div>
				<!-- /category nav -->

				<!-- menu nav --
				<div class="menu-nav">
					<span class="menu-header">Menu <i class="fa fa-bars"></i></span>
					<ul class="menu-list">
						<li><a href="index.php">Home--</a></li>
						<li><a href="#">Sell With Us--</a></li>
							
					</ul>
				</div>
				<!-- menu nav -->
			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->