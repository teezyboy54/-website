<?php 

session_start();
error_reporting(0);
include('config.php');

if(isset($_POST['submit'])){
if(!empty($_SESSION['cart'])){
foreach($_POST['quantity'] as $key => $val){
if($val==0){
unset($_SESSION['cart'][$key]);
}else{
$_SESSION['cart'][$key]['quantity']=$val;

}
}
$_SESSION['edit']="Your Cart Has Been Updated";

header('location: ../my-cart.php');
//echo "<script>alert('Your Cart hasbeen Updated');</script>";
}
}

// Code for Remove a Product from Cart
if(isset($_POST['remove_code']))
{

if(!empty($_SESSION['cart'])){
foreach($_POST['remove_code'] as $key){

unset($_SESSION['cart'][$key]);
}
$_SESSION['remove']="Your Cart Has Been Deleted";
header('location: ../my-cart.php');

//echo "<script>alert('Your Cart has been Updated');</script>";
}
} 


if(isset($_POST['ordersubmit'])) 
{

if(strlen($_SESSION['login'])==0)
{   
header('location:../login.php');
}
else{
	$_SESSION['quantity']=$_POST['quantity'];
header('location:../Confirm.php');	
}
/*else{

$quantity=$_POST['quantity'];
$pdd=$_SESSION['pid'];
$value=array_combine($pdd,$quantity);



foreach($value as $qty=> $val34){



mysqli_query($con,"insert into orders(userId,productId,quantity,shippingCharge ) values('".$_SESSION['id']."','$qty','$val34','".$_SESSION['Delivery']."')");
header('location:Confirm.php');
}
}*/
}


/*
// Code for Remove a Product from Cart
if(isset($_POST['remove_code']))
	{

if(!empty($_SESSION['cart'])){
		foreach($_POST['remove_code'] as $key){
			
				unset($_SESSION['cart'][$key]);
		}
			$_SESSION['remove']="Your Cart Has Been Updated";
header('location: ../my-cart.php');
	}
}

// Code for Remove a Product from Cart
if(isset($_POST['remove_code']))
{

if(!empty($_SESSION['cart'])){
foreach($_POST['remove_code'] as $key){

unset($_SESSION['cart'][$key]);
}
$_SESSION['remove']="Your Cart Has Been Updated";
header('location: ../my-cart.php');

//echo "<script>alert('Your Cart has been Updated');</script>";
}
}
*/

?>