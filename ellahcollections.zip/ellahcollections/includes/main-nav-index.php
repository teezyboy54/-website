<div class="menu-nav">
					<!--<span class="menu-header">Menu <i class="fa fa-bars"></i></span>-->
					<ul class="menu-list">
						<li><a href="index.php">Home</a></li>
						<li><a href="#">About Us</a></li>
						
					</ul>
				</div>