

<?php

$con = mysqli_connect ("localhost", "root", "", "ellah");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
} 




?>