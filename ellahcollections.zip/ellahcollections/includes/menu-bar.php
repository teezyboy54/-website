<li class="header-cart dropdown default-dropdown">
							<?php
if(!empty($_SESSION['cart'])){
	?>
							<a href="my-cart.php" class="dropdown-toggle" data-toggl="dropdown" aria-expanded="true">
								<div class="header-btns-icon">
									<i class="fa fa-shopping-cart"></i>
									<span class="qty"><?php echo $_SESSION['qnty'];?></span>
								</div>
								<strong class="text-uppercase">My Cart: </strong>
								<br>
								<span><i style="font-size: 11px;">N</i><?php echo  $_SESSION['tp']; ?></span>
							</a>
							<div class="custom-menu">
								 <?php
    $sql = "SELECT * FROM products WHERE id IN(";
			foreach($_SESSION['cart'] as $id => $value){
			$sql .=$id. ",";
			}
			$sql=substr($sql,0,-1) . ") ORDER BY id ASC";
			$query = mysqli_query($con,$sql);
			$totalprice=0;
			$totalqunty=0;
			if(!empty($query)){
			while($row = mysqli_fetch_array($query)){
				$quantity=$_SESSION['cart'][$row['id']]['quantity'];
				$subtotal= $_SESSION['cart'][$row['id']]['quantity']*$row['productPrice'];
				$totalprice += $subtotal;
				$_SESSION['qnty']=$totalqunty+=$quantity;

	?>
								<div id="shopping-cart">
									<!--<div class="shopping-cart-list">-->
										<div class="product product-widget">
											<div class="product-thumb">
												<a href="#"><img  src="admin/productimages/<?php echo $row['id'];?>/<?php echo $row['productImage1'];?>" width="35" height="50" alt=""></a>
											</div>
											<div class="product-body">
												<h3 class="product-price" style="color: #e80505;"><?php echo "N ". ($row['productPrice']+$row['shippingCharge']); ?><span style="color: #101010;">*</span><?php echo $_SESSION['cart'][$row['id']]['quantity']; ?> <span class="qty"></span></h3>
												<h2 class="product-name"><a href="index.php?page-detail"><?php echo $row['productName']; ?></a></h2>
											</div>
											<!--<button class="cancel-btn"><i class="fa fa-trash"></i></button>-->
										<!--</div>-->
										
									</div><?php } }?> 
									<hr>
									<div class="pull-left">
					
						<span class="text" style="color: #101010;">Total :</span><span class='price' style="color: #e80505;"><?php echo "N ". $_SESSION['tp']="$totalprice". ".00"; ?></span>
						
							</div><br>
									 <div class="shopping-cart-btns">
										<form action="my-cart.php">
											<input type="submit" class="primary-btn" style="width: 100%" value="View Cart">

										</form>
										<!--<a href="my-cart.php" clas="btn btn-upper btn-primary btn-block m-t-20"><button class="main-btn">Checkout</button>		
										<button class="primary-btn" style="width: 100%"> View Cart<i class="fa fa-arrow-circle-right"></i></button></a>-->	

									</div>
								</div>
							</div>
						</li><?php } else { ?>

							<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
								<div class="header-btns-icon">
									<i class="fa fa-shopping-cart"></i>
									<span class="qty"><?php echo "0" ;?></span>
								</div>
								<strong class="text-uppercase"><!--My Cart:--></strong>
								<br>
								<span><i style="font-size: 11px;">N</i><?php echo " 0.00" ;?></span>
							</a>
							<div class="custom-menu">
								 
								<div id="shopping-cart">
									<!--<div class="shopping-cart-list">-->
										<div class="product product-widget">
											
											<div cass="product-body">
												<h5 class="product-price" style="color: #101010;">Your Shopping Cart is Empty.</h5>
												
											</div>
											<!--<button class="cancel-btn"><i class="fa fa-trash"></i></button>-->
										<!--</div>-->
										
									</div>
									<hr>
									<div class="pull-right">				
							</div><br>
									<div class="shopping-cart-btns">
										
										<a href="index.php" clas="btn btn-upper btn-primary btn-block m-t-20"><button class="primary-btn" style="width: 100%">Continue Shooping <i class="fa fa-arrow-circle-right"></i></button></a>
									</div>
								</div>
							</div>
						</li>

<?php } ?>
						<!-- /Cart -->