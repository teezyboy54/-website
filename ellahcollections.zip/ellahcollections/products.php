	<?php
session_start();
error_reporting(0);
include('includes/config.php');
$cid=intval($_GET['cid']);
$sid=intval($_GET['sid']);
if(isset($_GET['action']) && $_GET['action']=="add"){
	$id=intval($_GET['id']);
	if(isset($_SESSION['cart'][$id])){
		$_SESSION['cart'][$id]['quantity']++;
	}else{
		$sql_p="SELECT * FROM products WHERE id={$id}";
		$query_p=mysqli_query($con,$sql_p);
		if(mysqli_num_rows($query_p)!=0){
			$row_p=mysqli_fetch_array($query_p);
			$_SESSION['cart'][$row_p['id']]=array("quantity" => 1, "price" => $row_p['productPrice']);
			header('location:my-cart.php');
		}else{
			$message="Product ID is invalid";
		}
	}
}
// COde for Wishlist
if(isset($_GET['pid']) && $_GET['action']=="wishlist" ){
	if(strlen($_SESSION['login'])==0)
    {   
header('location:login.php');
}
else
{
mysqli_query($con,"insert into wishlist(userId,productId) values('".$_SESSION['id']."','".$_GET['pid']."')");
echo "<script>alert('Product added in wishlist');</script>";
header('location:my-wishlist.php');

}
}
?>



	<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php'); ?>

<body>
	<!-- HEADER -->
	<header>
		<!-- top Header -->
		<?php  include('includes/top-header.php'); ?>
		<!-- /top Header -->

		<!-- header -->
		<?php  include('includes/main-header.php'); ?>
		
		<!-- container -->
	</header>
	<!-- /HEADER -->

	<!-- NAVIGATION -->
	<?php include 'includes/main-nav.php'; ?>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			
			<?php
								$ret=mysqli_query($con,"SELECT category.categoryName as catname,subCategory.subcategory as subcatname,products.* from products join category on category.id=products.category join subcategory on subcategory.id=products.subCategory where products.id='$pid'");
								while ($rw=mysqli_fetch_array($ret)) {

								?>
							<ul class="breadcrumb">

								<li><a href="index.php">Home</a></li>
								<li><a href="products.php?cid=<?php echo  $rw['category']; ?>"><?php echo htmlentities($rw['catname']);?></a></li>
								<li><a href="subcategory-products.php?sid=<?php echo $rw['subCategory']; ?>"><?php echo htmlentities($rw['subcatname']);?></a></li>
								<!--<li><a href="checkout.php"><?php echo htmlentities($rw['pname']);?></a></li>-->
								<li><a href="#"><?php echo htmlentities($rw['productName']);?></a></li>
							</ul><?php }?>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				

				<!-- MAIN -->
				<div id="main" class="col-md-12">
					

					<!-- STORE -->
					<div id="store">
						<!-- row -->
						<div class="row">
							<!-- Product Single -->
<?php
$ret=mysqli_query($con,"SELECT * from products where category='$cid' ");
$num=mysqli_num_rows($ret);
if($num>0)
{
while ($row=mysqli_fetch_array($ret)) 
{?>							
							<div class="col-md-2 col-sm-4 col-xs-4">
								
									<div class="product product-single">
								<a href="product-page.php?pid=<?php echo htmlentities($row['id']);?>"><div class="product-thumb">
									<img style="width: 100%;  height: 160px;" src="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" data-echo="admin/productimages/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage1']);?>" alt="" >
								</div></a>
								<div class="caption">
                                <p><a href="product-page.php?pid=<?php echo htmlentities($row['id']);?>"><?php echo htmlentities(substr($row['productName'],0,10));?></a></p>

                                <h5 class="product-price"> <?php echo "N ". htmlentities($row['productPrice']);?><span style="color: white;">.</span><del class="product-old-price"><?php if($row['productPriceBeforeDiscount']==0){}else{
							echo "N ".htmlentities($row['productPriceBeforeDiscount']);}?></del></h5>
							                                
                            </div>
							</div>
							</div>
						<?php } } else {?>
	
		<div class="col-sm-6 col-md-4 wow fadeInUp"> <h3>No Product Found</h3>
		</div>
		
<?php } ?>
							
						<!-- /widget product -->
					</div>
					<!-- /aside widget -->
				</div>
				<!-- /ASIDE -->


			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- FOOTER -->
<?php include 'includes/footer.php'; ?>
<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
